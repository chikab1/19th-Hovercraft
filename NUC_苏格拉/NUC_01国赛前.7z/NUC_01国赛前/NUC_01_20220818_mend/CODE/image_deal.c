
#include "headfile.h"
#include"stdio.h"
#define CAMERA_H   70
#define CAMERA_W  188
float  BlackThres = 160.0;   //�ڰ���ֵ
uint8 kk,bai_flag=0,hei_flag=0,baihei_flag=0,heibai_flag=0,width_heibai=0;
uint8 s1,s2,s3,s4;
uint8 twolines_trend=2;
uint8 uart_buf[10];
extern uint16 time_flag;/////////////
uint16 time_flag1;
int Point_last1=95,Point_last2=95,Point_last3=95;
uint8 qvlv_quanju_right=0,qvlv_quanju_left=0,qulv_jinduan_right=0,qulv_jinduan_left=0,qulv_yuandaun_right=0,qulv_yuandaun_left=0;
int qvlv_quanju=0, qulv_jinduan=0,qulv_yuandaun=0;
int  three_cross_cnt=0;
uint8 center_th[70];
uint8 check_line=17;
float k_center=0;
uint8 times2 = 0;
uint8 cnt3=0;
int th_y=0;
uint8 black_blocks = 0;
       uint8 cursor = 0;    //ָ��ջ�����α�thy
int n=0;
float trend_of_left = 0;
float trend_of_right = 0;
float  k_left=0;
float  k_right=0;
float parameterB=0, parameterA=0;
uint8 Index_Y = 0;
uint8 Index_Y_last=0,Index_X_last=0;
uint8 Index_X = 0;
uint8 guaidian_leftnum = 0,three_cross=0,three_cross1=0;
float curvity_right=0;
float curvity_left=0;
uint8 r_start=0;
uint8 l_start=0;
uint8 times=0;
uint8 youxie_shizi=0;
uint8 zuoxie_shizi=0;
uint8 findleftdownguai=0;
uint8 findrightdownguai=0;
uint8 findrightupguai = 0;
uint8 findleftupguai = 0;
uint8 xk=0,xj=0;
uint8 guaidian;

uint8 quanzhi_num=0;
/***ƫ��Ȩ��***/
const uint8 Weight[70] =
{
        1, 1, 1, 1, 1, 1,1, 1,1, 1,                //ͼ����Զ��60����70��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��   0����10��Ȩ��
        1, 1, 1, 1, 2, 3, 4, 6, 8,11,              //ͼ����Զ��10����20��Ȩ��
        15,17,18,21,20,19,18,17,16,15,              //ͼ����Զ��20����30��Ȩ��
        13,12,11,10, 9, 8, 7, 6, 5, 4,              //ͼ����Զ��30����40��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��40����50��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��50����60��Ȩ��
};//69

const uint8 Weight_jtai[26] =
{
        2, 3, 4, 6, 8,11,              //ͼ����Զ��10����20��Ȩ��
        15,17,18,21,20,19,18,17,16,15,              //ͼ����Զ��20����30��Ȩ��
        13,12,11,10, 9, 8, 7, 6, 5, 4,              //ͼ����Զ��30����40��Ȩ��
             //ͼ����Զ��50����60��Ȩ��
};//69



const uint8 Weight_huandao[70] =
{
        1, 1, 1, 1,1,  1, 1,1,1,1,             //ͼ����Զ��60����70��Ȩ��
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��   0����10��Ȩ��
       1, 1, 1, 1, 2, 3, 4, 6, 8,11,              //ͼ����Զ��10����20��Ȩ��
      15,17,18,21,20,19,18,17,16,15,              //ͼ����Զ��20����30��Ȩ��
      13,12,11,10, 9, 8, 7, 6, 5, 4,              //ͼ����Զ��30����40��Ȩ��
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��40����50��Ȩ��
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��50����60��Ȩ��

};//69
const uint8 Weight_huihuan[70] =
{
        1, 1, 1, 1,1,1,1, 1,1,1, 1, 1,               //ͼ����Զ��60����70��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��   0����10��Ȩ��
        1, 1, 1, 1, 2, 3, 4, 6, 8,11,              //ͼ����Զ��10����20��Ȩ��
        15,17,18,21,20,19,18,17,16,15,              //ͼ����Զ��20����30��Ȩ��
        13,12,11,10, 9, 8, 7, 6, 5, 4,              //ͼ����Զ��30����40��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��40����50��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1,
};//69
uint8 huihuan_num=0,zhidao_num=0,huandao_7=0;
//const uint8 Weight_huihuan_flag[70]=
//{
//        01,01,01,01,01,01,01,01,01,01,
//        1,1,1,1,1,1, 1,1,1,1,1,1,1,1,
//        1,1,1,1, 1,1,1,1,1,1,
//        1,1,1,1,1,1,1,1,1,1,
//        2,3,4,6,8,11,15,17,18,21,
//        20,19,18,17,16,15,13,12,11,10,
//        9,8,7,6,5,4,
//
//
//};


uint8 weight_jubu[70]=
{        1, 1, 1, 1, 1, 1,1, 1,1, 1,                //ͼ����Զ��60����70��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��   0����10��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,               //ͼ����Զ��10����20��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,             //ͼ����Զ��20����30��Ȩ��
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1,               //ͼ����Զ��30����40��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��40����50��Ȩ��
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,              //ͼ����Զ��50����60��Ȩ��;
};
const uint8 Weight_park[70] =
{
2,3,4,6,8,11,15,17,18,21,
20,19,18,17,16,15,13,12,11,10,
0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,
0,0
};//69
int j_flag=0;

int8 huihuan_left=0;
int8 huihuan_right=0;
uint8 bai_flag2=0,hei_flag2=0,baihei_flag2=0,heibai_flag2=0;
uint8 stop_you=0,stop_zuo=0;
int32 Sum = 0, Weight_Count = 0;
int stop_num1=0,stop_num2=0;
uint8 park_flag=0;//ͣ����־
uint8 Foresight_Left=0, Foresight_Right=186;
int Point_Mid=0,Point=0,Foresight=0;
uint8 image_use[70][188];
uint8 whitenum=0;
//

uint8   Half_width[70]=
{
        00,00,00,00,00,00,00,00,00,15,
         16,16,17,46,47,48,49,50,51,52,
         54,55,55,55,56,56,57,57,58,58,
         59,59,60,60,62,62,63,64,65,65,
         66,66,67,67,68,68,69,70,70,70,
         70,71,71,71,72,72,72,73,73,73,
         74,74,74,75,75,76,76,77,77,78
};
uint8  const Half_width2[70]=
{
        00,00,00,00,00,00,00,00,00,15,
        16,16,17,46,47,48,49,50,51,52,
        54,55,55,55,56,56,57,57,58,58,
        59,59,60,60,62,62,63,64,65,65,
        66,66,67,67,68,68,69,70,70,70,
        70,71,71,71,72,72,72,73,73,73,
        74,74,74,75,75,76,76,77,77,78
};

//uint8  const Half_width_handao[70]=  //time_flag
//        {
//                00,00,00,00,00,00,00,00,00,7,
//                8,8,9,38,39,40,41,42,43,44,
//                46,47,47,47,48,48,49,49,50,50,
//                51,51,52,52,54,54,55,59,60,60,
//                61,61,62,62,63,63,64,65,65,65,
//                65,66,66,66,67,67,67,68,68,68,
//                69,69,69,70,70,71,71,72,72,73
//        };

uint8   Half_width_handao[70]=  //time_flag
{
          00,00,00,00,00,00,00,00,00,10,
         11,11,12,14,15,16,17,18,19,20,
         28,28,29,29,30,31,31,32,32,33,
         48,51,52,52,54,54,55,59,60,60,
         61,61,62,62,63,63,64,65,65,65,
         65,66,66,66,67,67,67,68,68,68,
         69,69,69,70,70,71,71,72,72,73
};
uint8  const Half_width_handao2[70]=  //time_flag
{
                        00,00,00,00,00,00,00,00,00,10,
                        11,11,12,14,15,16,17,18,19,20,
                        28,28,29,29,30,31,31,32,32,33,
                        48,51,52,52,54,54,55,59,60,60,
                        61,61,62,62,63,63,64,65,65,65,
                        65,66,66,66,67,67,67,68,68,68,
                        69,69,69,70,70,71,71,72,72,73
};
//uint8  const Half_width_handao[70]=  //time_flag   ��˿��1111  ������
//        {
//                00,00,00,00,00,00,00,00,00,10,
//                11,11,12,14,15,16,17,18,19,20,
//                28,28,29,29,30,31,31,32,32,33,
//                48,51,52,52,54,54,55,59,60,60,
//                61,61,62,62,63,63,64,65,65,65,
//                65,66,66,66,67,67,67,68,68,68,
//                69,69,69,70,70,71,71,72,72,73
//        };
//uint8  const Half_width_handao[70]=
//        {
//                00,00,00,00,00,00,00,00,00,10,
//                13,13,14,16,17,18,19,20,21,22,
//                30,30,31,31,32,33,33,34,34,38,
//                50,53,54,54,56,56,57,61,62,62,
//                63,63,63,64,65,65,66,67,67,67,
//                67,68,86,68,69,9,69,70,70,70,
//                71,71,71,72,72,3,73,74,74,75
//        };
uint8  const Half_width_yuanshi[70]=
{
00,00,00,00,00,00,00,00,00,10,
11,11,12,14,15,16,17,18,19,20,
28,28,29,29,30,31,31,32,32,33,
34,35,35,36,37,38,39,40,41,41,
42,42,43,43,44,44,45,45,45,46,
46,46,47,48,49,50,52,53,53,54,
55,56,57,57,58,59,60,61,62,63
};
//uint8  const Half_width[70]=
//{
//00,00,00,00,00,00,00,00,00,10,
//11,11,12,14,15,16,17,18,19,20,
//21,22,23,24,25,25,26,37,43,43,
//44,45,45,46,47,47,48,49,50,50,
//51,52,53,54,55,55,56,57,58,59,
//60,61,62,64,64,65,67,68,68,69,
//70,73,73,73,74,74,75,76,77,78
//};
uint8 c=0;
uint8 huan2_flag=0;
uint8 star_lineflag=0,star_lineflag2=0;
uint8 y=0;
uint8 left_line[70],right_line[70];//��߽��ұ߽�     [0]  is  x,[1]  is  y
uint8 Left_Add2[70], Right_Add2[70];
uint8 Left_Add[70], Right_Add[70],Left_Add_num=0,Right_Add_num=0,Left_Add_num2=0,Right_Add_num2=0;
uint8 sousuojieshuhang;//����������
float Add_Slope=0,Left_Last_Slope=0,Right_Last_Slope=0;

uint8 center[70],Width[70];//����
uint8 youdiuxianshu=0;//�Ҷ�����
uint8 zuodiuxianshu=0;//������
uint8 zongdiuxianshu=0;//�ܶ�����

uint8 white_num_col[188],white_num_col_max=0,white_num_col_line=0,white_num_col_min_line=0,white_num_col_min=69;
 float Up_R_qulv;//��ǰ����ǰ�벿�����ʰ뾶
 float Down_R_qulv;//��ǰ������벿�����ʰ뾶
uint8  Left_Add_Start=0,Left_Add_End=0;
uint8  Right_Add_Start=0,Right_Add_End=0;
uint8 threshold1=0,threshold1_old=77;
uint8  threshold2=0,threshold2_old=77;


uint8 Thresholds[3]={0};
uint8 xielv_1eft2=80;
uint8 xielv_right2=80;
uint8 xielv=22;

uint8 Width_Min=69;
uint8 Right_y=0,Left_y=0;
uint8 Left_Max, Right_Min,Mid_Count;
uint8 Left_Line_New[70], Right_Line_New[70];//�߽粹�ߵ�����
uint8 Left_Line_New2[70], Right_Line_New2[70];//�߽粹�ߵ�����
uint8 temp_r=185;

uint8 curvity_point2=0;
uint8 curvity_point1=0;
uint8 flag_shizi=0;
uint8 right_turn_down[2]={69,187};
uint8 left_turn_down[2]={69,0};
uint8 right_turn_up[2]={0,0};
uint8 left_turn_up[2]={0,0};
/*****************��򷨲���*********************/
float bin_float[256];     //�Ҷȱ���ֱ��ͼ
int size = 70 * 186;
float u = 0;                //ȫͼƽ���Ҷ�
float w0 = 0;
float u0 = 0;               //ǰ���Ҷ�
uint8 Bin_Array[256];
int i;
float gray_hh = 0;//ǰ���ҶȺ�
float var = 0;//����
float maxvar = 0;//��󷽲�
float maxgray = 0;//���Ҷ�ռ��
float maxbin = 0;

struct size_point
{
        int x0;
        int y0;
        int x1;
        int y1;
};

//struct size_point ostu_point[3]={
//        {0,0,15,69},
//        {16,0,160,69},
//        {161,0,186,69},
//};
struct size_point ostu_point[3]={
{0,0,40,69},
{41,0,135,69},
{136,0,186,69},
};
/*****************��򷨲���end*********************/
void Ostu(void)//���
{
    int j, k;
    uint8 (*p_image)[188] = &mt9v03x_image[0];
      threshold1= my_adapt_threshold(mt9v03x_image[0],188,70);
    for (k = 0; k < 3; k++)
    {
        maxvar = 0;
        w0 = 0;
        u = 0;
        gray_hh = 0;
        var = 0;
        Thresholds[k] = 0;
        for (i = 0; i < 256; i++)
        { bin_float[i] = 0; }
        for (i = ostu_point[k].y0; i <= ostu_point[k].y1; i++)
        {
                for (j = ostu_point[k].x0; j <= ostu_point[k].x1; j++)
                {
                        ++bin_float[*(*(p_image + i) + j)];
                }
        }
        size = (ostu_point[k].y1 - ostu_point[k].y0 + 1) * (ostu_point[k].x1 - ostu_point[k].x0 + 1);
        for (i = 0; i < 256; i++)
        {
                bin_float[i] = bin_float[i] / size;
                u += i * bin_float[i];
        }
        //���������Ҷ�ֱ��ͼ
        for (i = 0; i < 256; i++)
        {
                w0 += bin_float[i];
                gray_hh += i * bin_float[i];             //�ҶȺ�
                u0 = gray_hh / w0;
                var = (u0 - u) * (u0 - u) * w0 / (1 - w0);
                if (var > maxvar)
                {
                        maxgray = gray_hh;
                        maxbin = w0;
                        maxvar = var;
                        Thresholds[k] = (uint8)i;

                }
        }
        if (k == 0)
        {
                if (gray_hh > 15 && gray_hh <= 33)
                {
                        if (maxbin < 0.9f)
                        {
                                Thresholds[k] = (uint8)(Thresholds[1] - 3);
                        }
                }
                else if (gray_hh > 41 && gray_hh <= 47)
                {
                        if (maxbin < 0.64f || maxbin > 0.76f)
                        {
                                Thresholds[k] = (uint8)(Thresholds[1] - 3);
                        }
                }
                else if (gray_hh > 50 && gray_hh <= 60)
                {
                        if (maxbin < 0.42f || maxbin > 0.58f)
                        {
                                Thresholds[k] = (uint8)(Thresholds[1] - 3);
                        }
                }
                                                                 if (abs(threshold1 - Thresholds[k]) >= 30)//���̫��ֱ���ñ�׼ֵ
                                                                                                {
                                                                                                    Thresholds[k] = threshold1;
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    Thresholds[k] = (uint8)(Thresholds[k] + 0.5f * (threshold1 - Thresholds[k]));//������ȡ��ƽ��������ͨ������ռ����Ӧ��ͬ�Ĺ�������
                                                                                                }
                //SetText("�ұ�var:" + maxvar + " ��ֵ:" + Thresholds[k] + " ����:" + maxbin + " �ҶȺ�" + gray_hh);
        }
        else if (k == 1)
        {
                if(gray_hh > 69 && gray_hh < 80)
                {
                        if (maxbin > 0.15f)
                        {
                                Thresholds[k] = (uint8)(Thresholds[0] + 3);



                                                                                                }
                }
                                                                 if (abs(threshold1 - Thresholds[k]) >= 30)//���̫��ֱ���ñ�׼ֵ
                                                                                                {
                                                                                                    Thresholds[k] = threshold1;
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    Thresholds[k] = (uint8)(Thresholds[k] + 0.5f * (threshold1 - Thresholds[k]));//������ȡ��ƽ��������ͨ������ռ����Ӧ��ͬ�Ĺ�������
                                                                                                }
                //SetText("�м�var:" + maxvar + " ��ֵ:" + Thresholds[k] + " ����:" + maxbin + " �ҶȺ�" + gray_hh);
        }
        else if (k == 2)
        {
                if (maxbin < 0.85f && gray_hh < 28)
                {
                        Thresholds[k] = (uint8)(Thresholds[1] - 3);
                }
                else if(gray_hh > 69 && gray_hh < 79)
                {
                        if (maxbin < 0.5f || maxbin > 0.15f)
                        {
                                Thresholds[k] = (uint8)(Thresholds[1] - 3);
                        }
                }
                                                                 if (abs(threshold1 - Thresholds[k]) >= 30)//���̫��ֱ���ñ�׼ֵ
                                                                {
                                                                    Thresholds[k] = threshold1;
                                                                }
                                                                else
                                                                {
                                                                    Thresholds[k] = (uint8)(Thresholds[k] + 0.5f * (threshold1 - Thresholds[k]));//������ȡ��ƽ��������ͨ������ռ����Ӧ��ͬ�Ĺ�������
                                                                }
                //SetText("���var:" + maxvar + " ��ֵ:" + Thresholds[k] + " ����:" + maxbin + " �ҶȺ�" + gray_hh);
        }






        for (i = 0; i < Thresholds[k]; i++)
        {
                Bin_Array[i] = 0;
        }
        for (i = Thresholds[k]; i < 256; i++)
        {
                Bin_Array[i] = 255;
        }
        for (i = ostu_point[k].y0; i <= ostu_point[k].y1; i++)
        {
                for (j = ostu_point[k].x0; j <= ostu_point[k].x1; j++)
                {
                        image_use[i][j] = Bin_Array[*(*(p_image + i) + j)];
                }
        }
    }
}


/*****************���end*********************/


/***������*****/
struct size_point2
{
    int x0;
    int y0;
};

struct size_point2 stack_seed[6000];//ջ
uint16 stack_top = 0;
uint8 (*p_Pixels)[186] = &image_use[0];
uint8 Ostu_Threshold=0;
void pull_stack(uint8 x, uint8 y)//��ջ
{
    *(*(p_Pixels + y) + x) = 255;
    stack_seed[stack_top].x0 = x;
    stack_seed[stack_top].y0 = y;
    stack_top++;
}
struct size_point2 push_stack()//��ջ
{
    stack_seed[stack_top].y0 = 0;
    stack_seed[stack_top].x0 = 0;
    return stack_seed[--stack_top];
}

int panbianjie(uint8 x, uint8 y)
{
    if (x + y == 0)
    {
            return 0;
    }
    return (int)((abs(x - y) * 100 / (x + y)) + 0.5f);
}

struct size_point2 connects[8]={ //������ɨ��
//{-1,-1},
//{0,-1},
//{1,-1},
{1,0},
//{1,1},
{0,1},
//{-1,1},
{-1,0}
};

void SignalProcess_grayfine_fill(void)
 {
        int j,px,py;
        struct size_point2 center_seed;
        uint8 (*p_image)[188] = &mt9v03x_image[0];
        p_Pixels = &image_use[0];
        stack_top = 0;
        for (i = 0; i <= 69; i++)
        {
            for (j = 0; j <= 185; j++)
            {
                    *(*(p_Pixels + i) + j) = 0;
            }
        }
        Ostu_Threshold = threshold1;

        for (i = 0; i < 186; i++)
        {
            if (Ostu_Threshold - *(*(p_image + 0) + i + 1) < 5)
                    pull_stack((uint8)i, 0);
        }
        while (stack_top != 0)
        {
            center_seed = push_stack();
            px = center_seed.x0 + connects[0].x0;
            py = center_seed.y0 + connects[0].y0;
            if (*(*(p_Pixels + py) + px) == 1 || px < 0 || py < 0 || px >= 186 || py >= 70)
            {}
            else
            {
                    if (abs(*(*(p_image + py) + px + 1)- *(*(p_image + center_seed.y0) + center_seed.x0 + 1)) < 8 && Ostu_Threshold - *(*(p_image + py) + px + 1) < 5)
                    {
                                    pull_stack((uint8)px, (uint8)py);
                    }
            }

            px = center_seed.x0 + connects[1].x0;
            py = center_seed.y0 + connects[1].y0;
            if (*(*(p_Pixels + py) + px) == 1 || px < 0 || py < 0 || px >= 186 || py >= 70)
            {}
            else
            {
                    if (abs(*(*(p_image + py) + px + 1)- *(*(p_image + center_seed.y0) + center_seed.x0 + 1)) < 8 && Ostu_Threshold - *(*(p_image + py) + px + 1) < 5)
                    {
                            pull_stack((uint8)px, (uint8)py);
                    }
            }

            px = center_seed.x0 + connects[2].x0;
            py = center_seed.y0 + connects[2].y0;
            if (*(*(p_Pixels + py) + px) == 1 || px < 0 || py < 0 || px >= 186 || py >= 70)
            {}
            else
            {
                    if (abs(*(*(p_image + py) + px + 1)- *(*(p_image + center_seed.y0) + center_seed.x0 + 1)) < 8 && Ostu_Threshold - *(*(p_image + py) + px + 1) < 5)
                    {
                            pull_stack((uint8)px, (uint8)py);
                    }
            }
        }
}
/***������*****/

void bu_breakhang(int c1, int c2, uint8 j)
{

    int k = center[c2] - center[c1];

    if(j>40)
    {
            if (k >1) //������
            {
                for (uint8 i = j; i >= 11; i--)
                {
                    center[i] = 2;


                }
            }
            else if (k < 1)  //������
            {
                for (uint8 i = j; i >= 11; i--)
                {
                    center[i] =184;
                }
            }
            else//          ֱ����0
            {
                 for (uint8 i = j; i >= 1; i--)
                {
                    center[i] = 93;
                }
            }
    }

}

void advanced_regression(int type, int startline1, int endline1, int startline2, int endline2)
{
    int i = 0;
    int sumlines1 = endline1 - startline1;
    int sumlines2 = endline2 - startline2;
    int sumX = 0;
    int sumY = 0;
    float averageX = 0;
    float averageY = 0;
    float sumUp = 0;
    float sumDown = 0;
    if (type == 0)  //�������
    {
        /**����sumX sumY**/
        for (i = startline1; i < endline1; i++)
        {
            sumX += i;
            sumY += center_th[i];
        }
        for (i = startline2; i < endline2; i++)
        {
            sumX += i;
            sumY += center_th[i];
        }
        averageX = sumX / (sumlines1 + sumlines2);     //x��ƽ��ֵ
        averageY = sumY / (sumlines1 + sumlines2);     //y��ƽ��ֵ
        for (i = startline1; i < endline1; i++)
        {
            sumUp += (center_th[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        for (i = startline2; i < endline2; i++)
        {
            sumUp += (center_th[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;

    }
    else if (type == 1)     //�������
    {
        /**����sumX sumY**/
        for (i = startline1; i < endline1; i++)
        {
            sumX += i;
            sumY += left_line[i];
        }
        for (i = startline2; i < endline2; i++)
        {
            sumX += i;
            sumY += left_line[i];
        }
        averageX = sumX / (sumlines1 + sumlines2);     //x��ƽ��ֵ
        averageY = sumY / (sumlines1 + sumlines2);     //y��ƽ��ֵ
        for (i = startline1; i < endline1; i++)
        {
            sumUp += (left_line[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        for (i = startline2; i < endline2; i++)
        {
            sumUp += (left_line[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;
    }
    else if (type == 2)         //�������
    {
        /**����sumX sumY**/
        for (i = startline1; i < endline1; i++)
        {
            sumX += i;
            sumY += right_line[i];
        }
        for (i = startline2; i < endline2; i++)
        {
            sumX += i;
            sumY += right_line[i];
        }
        averageX = sumX / (sumlines1 + sumlines2);     //x��ƽ��ֵ
        averageY = sumY / (sumlines1 + sumlines2);     //y��ƽ��ֵ
        for (i = startline1; i < endline1; i++)
        {
            sumUp += (right_line[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        for (i = startline2; i < endline2; i++)
        {
            sumUp += (right_line[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;
    }

}

void find_rightdown_point(uint8 start_point, uint8 end_point, uint8 RoadName)
{
    uint8 j;
    if (RoadName == 1)
    {
        for (j = start_point; j >= end_point; j--)
        {
            //���ұ�ͻ��(�¹յ�)
            if (j>=sousuojieshuhang+4&&abs(right_line[j + 1] - right_line[j + 2]) <= 3 && abs(right_line[j] - right_line[j + 1]) <= 3 && (right_line[j - 1] - right_line[j])>= 1&& (right_line[j - 2] - right_line[j])>= 2&& (right_line[j - 3] - right_line[j])>= 3
                && Right_Add[j + 2] == 0 && Right_Add[j + 1] == 0 && Right_Add[j] == 0)
            {
                right_turn_down[0] = j + 1;//��������û�е�0��
                right_turn_down[1] = right_line[j];
                break;
            }
        }
    }
    else if (RoadName == 2)
    {
         for (j = start_point; j >= end_point; j--)
        {
            //���ұ�ͻ��(�¹յ�)
            if (r_start>65&&j>=sousuojieshuhang+4&&abs(right_line[j + 1] - right_line[j + 2]) <= 2 && abs(right_line[j] - right_line[j + 1]) <= 2 && (right_line[j - 1] - right_line[j])>= 1&& (right_line[j - 2] - right_line[j])>= 2&& (right_line[j - 3] - right_line[j])>= 3
                && Right_Add[j + 2] == 0 && Right_Add[j + 1] == 0 && Right_Add[j] == 0)
            {
                right_turn_down[0] = j + 1;//��������û�е�0��
                right_turn_down[1] = right_line[j];
                break;
            }
        }
        //������¹յ����겻Ϊ�� �� ����״̬����4 ���϶��ҵ����������¹յ�
       // if (f[0] != 0 && huandao_memory != 4) flag_find_huan_rightdown_point = 1;
    }
    else
    {

    }
}



//��Function6�������¹յ㺯��   abs
//���룺 start�� end��  ��Ҫ�жϵ��¹յ�����ͣ���������ʮ�֣���
void find_leftdown_point(uint8 start_point, uint8 end_point, uint8 RoadName)
{
    uint8 j;
    if (RoadName == 1)
    {
        for (j = start_point; j >= end_point; j--)
        {
            //�����ͻ��(�¹յ�)���������Ǵ��ڵĵ㣨��
//            if (j>=sousuojieshuhang+4&&abs(left_line[j + 1] - left_line[j + 2]) >= 2 && abs(left_line[j] - left_line[j + 1]) >=2 && (left_line[j ] - left_line[j-1])>=1&& (left_line[j ] - left_line[j-2])>=2&& (left_line[j ] - left_line[j-3])>=3
//                && Left_Add[j + 2] == 0 && Left_Add[j + 1] == 0 && Left_Add[j] == 0)
            if (j>=sousuojieshuhang+4&&abs(left_line[j + 1] - left_line[j + 2]) <= 3 && abs(left_line[j] - left_line[j + 1]) <=3 && (left_line[j ] - left_line[j-1])>=1&& (left_line[j ] - left_line[j-2])>=2&& (left_line[j ] - left_line[j-3])>=3
                           && Left_Add[j + 2] == 0 && Left_Add[j + 1] == 0 && Left_Add[j] == 0)
            {

                left_turn_down[0] = j;//��������û�е�0��
                left_turn_down[1] = left_line[j];
                break;
            }
        }
    }
    else if (RoadName == 2)
    {
        //setText�û��Զ���("l_start"+ l_start);
        for (j = start_point; j >= end_point; j--)
        {
            //�����ͻ��(�¹յ�)���������Ǵ��ڵĵ㣨��
            if (l_start>65&&j>=sousuojieshuhang+4&&abs(left_line[j + 1] - left_line[j + 2]) <= 2 && abs(left_line[j] - left_line[j + 1]) <=2 && (left_line[j ] - left_line[j-1])>=1&& (left_line[j ] - left_line[j-2])>=2&& (left_line[j ] - left_line[j-3])>=3
                && Left_Add[j + 2] == 0 && Left_Add[j + 1] == 0 && Left_Add[j] == 0)
            {

                left_turn_down[0] = j;//��������û�е�0��
                left_turn_down[1] = left_line[j];
                break;
            }
        }
    //    if (left_turn_down[0] != 0 && huandao_memory != 4) flag_find_huan_leftdown_point = 1;
    }
    else
    {

    }
}

unsigned int my_sqrt(int x)
{
 uint8 ans=0,p=0x80;
 while(p!=0)
 {
 ans+=p;
 if(ans*ans>x)
 {
 ans-=p;
 }
 p=(uint8)(p/2);
 }
 return(ans);
}
float process_curvity(uint8 x1, uint8 y1, uint8 x2, uint8 y2, uint8 x3, uint8 y3)
{
    float K;
    int S_of_ABC = ((x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)) / 2;
    //����ķ��ű�ʾ����
    char q1 = (char)((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    char AB = my_sqrt(q1);
    q1 = (char)((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
    char BC = my_sqrt(q1);
    q1 = (char)((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));
    char AC = my_sqrt(q1);
    if (AB * BC * AC == 0)
    {
        K = 0;
    }
    else
        K = (float)4 * S_of_ABC / (AB * BC * AC);
    return K;
}



char oppositeSigns(int x, int y)
{
    return ((x ^ y) < 0);
}
void Cal_losttimes(int times)
{
    uint8 i;
    uint8 flag_of_rightbreak = 0;
    uint8 flag_of_leftbreak = 0;
    if(times<20)times=20;
    for (i = 67; i > times; i--)
    {
        //���߲���
        if (Left_Add[i] == 1)       //δɨ����
        {
            zuodiuxianshu++;
            if (flag_of_leftbreak == 0)     //�������һ��֮ǰû���������ߣ������
            {
                l_start=i;
            }
        }
        else    //ɨ����
        {
            //lostleft_times����������
            flag_of_leftbreak = 1;  //break��־����
        }
        //���߲���
        if (Right_Add[i] == 1)       //δɨ����
        {
            youdiuxianshu++;
            if (flag_of_rightbreak == 0)     //�������һ��֮ǰû���������ߣ������
            {
                r_start=i;
            }
        }
        else    //ɨ����
        {
            //lostright_times����������
            flag_of_rightbreak = 1;  //break��־����
        }
    }

}

void Center_line_deal()//���ߴ���
    {
    k_center=0;
    qvlv_quanju_right=qvlv_quanju_left=qulv_jinduan_right=qulv_jinduan_left=qulv_yuandaun_right=qulv_yuandaun_left=0;
       k_left=0;
       k_right=0;
      Width_Min=100;
     // th_y=0;
      whitenum=0;
     right_turn_down[0]=69;
     left_turn_down[0]=69;
     right_turn_down[1]=187;
     left_turn_down[1]=1;
      // right_turn_up[0]=0;
     //  left_turn_up[0]=0;
    xielv_1eft2=80;
     xielv_right2=80;
      findleftdownguai=0;
      findrightdownguai=0;
       findrightupguai = 0;
       findleftupguai = 0;
      times=0;
      Foresight_Left=0, Foresight_Right=186;
      youdiuxianshu=0;
      zuodiuxianshu=0;
      Left_Add_Start=0;
      Right_Add_Start=0;
      Left_Add_End=0;
      Right_Add_End=0;
      white_num_col_max=0;
      Left_Add_num=0,Right_Add_num=0;
      Left_Add_num2=0,Right_Add_num2=0;
       white_num_col_min=69;
      l_start=68;r_start=68;
      for(int ql=0;ql<=69;ql++)   //���㺯��
      {
        left_line[ql]=2;
        Left_Add[ql]=0;
        Left_Add2[ql]=0;
        Left_Line_New[ql]=2;

      }
       for(int ql=0;ql<=187;ql++)   //���㺯��guaidian
      {
        white_num_col[ql]=0;

      }
      for(int ql=0;ql<=69;ql++)
      {
        right_line[ql]=184;
         Right_Line_New[ql]=184;
        center[ql]=89;
        Right_Add[ql]=0;
        Right_Add2[ql]=0;

      }
      uint8 x=0,y=0;     //��xΪ�У�yΪ��
      uint8 temp=0;
    ////////////////////////////ɨ�������3��/////////////////////////

    if(left_huan_num==3)//right_huan_num==6||
         {
                for(x=184;x>101;x--)
              {
                for(y=69;y>=0;y--)
                {
                  if(image_use[y][x]==0)
                  {
                    break;
                  }
                  else
                  {
                  white_num_col[x]++;
                  }
                }
                if(white_num_col[x]> white_num_col_max)
                {white_num_col_max=white_num_col[x];
                  white_num_col_line=x;
                }
              }
         }

     else if(right_huan_num==3)//||left_huan_num==6
     {
            for(x=18;x<101;x++)
          {
                for(y=69;y>=0;y--)
            {
              if(image_use[y][x]==0)
              {
                break;
              }
              else
              {
              white_num_col[x]++;
              }
            }
            if(white_num_col[x]> white_num_col_max)
            {white_num_col_max=white_num_col[x];
              white_num_col_line=x;
            }
          }
     }
     else
        {
              if(park_flag==1)
                  {
                     for(x=18;x<=100;x++)
                           {
                         for(y=69;y>=0;y--)
                             {
                               if(image_use[y][x]==0)
                               {
                                 break;
                               }
                               else
                               {
                               white_num_col[x]++;
                               }
                             }
                             if(white_num_col[x]> white_num_col_max)
                             {white_num_col_max=white_num_col[x];
                               white_num_col_line=x;
                             } // k_right
                           }
                                          for(x=184;x>=101;x--)
                                       {
                                              for(y=69;y>=0;y--)
                                         {
                                           if(image_use[y][x]==0)
                                           {
                                             break;
                                           }
                                           else
                                           {
                                           white_num_col[x]++;
                                           }
                                         }
                                       if(white_num_col[x]> white_num_col_max)
                                       {white_num_col_max=white_num_col[x];
                                         white_num_col_line=x;
                                       }
                                          }
                  }
        else if(park_flag==0)
        {

                                                 for(x=184;x>=101;x--)
                                              {
                                                     for(y=69;y>=0;y--)
                                                {
                                                  if(image_use[y][x]==0)
                                                  {
                                                    break;
                                                  }
                                                  else
                                                  {
                                                  white_num_col[x]++;
                                                  }
                                                }
                                              if(white_num_col[x]> white_num_col_max)
                                              {white_num_col_max=white_num_col[x];
                                                white_num_col_line=x;
                                              }
                                                 }
                                                 for(x=18;x<=100;x++)
                                       {
                                                     for(y=69;y>=0;y--)
                                         {
                                           if(image_use[y][x]==0)
                                           {
                                             break;
                                           }
                                           else
                                           {
                                            white_num_col[x]++;
                                           }
                                         }
                                         if(white_num_col[x]> white_num_col_max)
                                         {white_num_col_max=white_num_col[x];
                                           white_num_col_line=x;
                                         } // k_right
                                       }
                         }
        else  if(tingche_flag)
        {
                    if(c_r==2)
                    {
                                for(x=18;x<=115;x++)
                               {
                                    for(y=69;y>=0;y--)
                                 {
                                   if(image_use[y][x]==0)
                                   {
                                     break;
                                   }
                                   else
                                   {
                                   white_num_col[x]++;
                                   }
                                 }
                                 if(white_num_col[x]> white_num_col_max)
                                 {white_num_col_max=white_num_col[x];
                                   white_num_col_line=x;
                                 } // k_right
                               }
                    }
                    else if(c_r==1)
                    {
                        for(x=184;x>=85;x--)
                           {
                            for(y=69;y>=0;y--)
                             {
                               if(image_use[y][x]==0)
                               {
                                 break;
                               }
                               else
                               {
                               white_num_col[x]++;
                               }
                             }
                             if(white_num_col[x]> white_num_col_max)
                             {white_num_col_max=white_num_col[x];
                               white_num_col_line=x;
                             } // k_right
                           }
                    }
        }

        }

        for(y = 68;y >1;y--)    //x�Ǽ�59��56  num�Ǽ�0��4
        {
          for(x = white_num_col_line;x <=184;x++)    //�м�����������
            {
              if(image_use[y][x-1] == 255&&image_use[y][x] == 255&& image_use[y][x+1] == 0 && image_use[y][x+2] == 0 )  //���������ڵ㴥��
                {
                   right_line[y]=x;
                   Right_Line_New[y]=x;
                   Right_Line_New2[y]=x;
                   break;
                }
                else if(x==184)       //�����ұ��˶�ûɨ���ڵ�a
                {
                    right_line[y]=x;
                    Right_Line_New[y]=x;
                    Right_Line_New2[y]=x;
                    Right_Add[y]=1;

                    break;
                }
            }
            for(x = white_num_col_line;x >= 1 ; x--)            //�м�����������
            {
              if(image_use[y][x-2] == 0 &&image_use[y][x-1] == 0 &&  image_use[y][x] == 255&&  image_use[y][x+1] == 255)  //���������ڵ㴥��
                {
                    left_line[y]=x;
                    Left_Line_New[y]=x;
                    Left_Line_New2[y]=x;
                    break;
                }
              else if(x==3)                 //��������˶�ûɨ���ڵ�
                {

                     left_line[y]=x;
                     Left_Line_New[y]=x;
                     Left_Line_New2[y]=x;
                     Left_Add[y]=1;

                    break;
                }
            }
          //   Half_width[y]=abs(right_line[y]-left_line[y])/2;
           Width[y]=abs(right_line[y]-left_line[y]);
           if(left_line[y]<=3&&right_line[y]<184)
                     {
                       if(right_line[y]-Half_width_yuanshi[y]<=3)
                           center_th[y]=3;
                       else
                           center_th[y]=right_line[y]-Half_width_yuanshi[y];
                     }
                    else  if(left_line[y]>3&&right_line[y]>=184)
                     {
                       if(left_line[y]+Half_width_yuanshi[y]>=184)
                           center_th[y]=184;
                       else
                           center_th[y]=left_line[y]+Half_width_yuanshi[y];
                     }
                      else
                          center_th[y] = ( left_line[y] + right_line[y]) / 2;

       if (Width[y]>=Width[y+1]|| (Width[y] >= Width_Min))
       {

                        if (Left_Add2[y+1])
            {
                if (left_line[y] < Left_Line_New2[y+1]-1)    //��ǰһ�е���߽�ʵ�߱Ƚ�
                {
                    Left_Add2[y] = 1;
                }
            }
            else    //ǰһ��û�в���
            {
                if (left_line[y] < left_line[y+1]-1)    //��ǰһ�е���߽�ʵ�߱Ƚ�
                {
                    Left_Add2[y] = 1;
                }
            }
                    if (Right_Add2[y+1])
            {
                if (right_line[y] > Right_Line_New2[y+1]+1)
                {
                    Right_Add2[y] = 1;
                }
            }
            else    //ǰһ���ұ߽�û�в���
            {
                if (right_line[y] > right_line[y+1]+1)
                {
                    Right_Add2[y] = 1;
                }
            }



       }


               if (Left_Add2[y])    //�����Ҫ����
        {

                                  if(y<65)
                                  { if (!Left_Add_Start)    //�����û�м�¼��ʼ����λ��
            {

                Left_Add_Start = y; //��¼��߽粹�߿�ʼλ��
            }


                                                        Add_Slope = 1.0*(left_line[Left_Add_Start+6] - left_line[Left_Add_Start+1]) / 4;    //������ʶ���ǰ����ͼ��б��

                                        if (Add_Slope > 0)  //�޷�
                                        {
                                                        Add_Slope = 0;
                                        }
                temp = (char)((y - (Left_Add_Start+1)) * Add_Slope + left_line[Left_Add_Start+1]);//ͨ��б�����㲹�ߵ�λ��
                Left_Last_Slope = Add_Slope;    //�����ϴ���߽�б��


            Left_Line_New2[y] = range_protect(temp, 2,184);  //��ֱ���޸ı߽磬ֻ�����ڲ���������
                                  }
                                                    /* ��һ�β��ߣ�ֻ��¼������ͼ������ʾ */
//
        }
        if (Right_Add2[y])  //�ұ���Ҫ����
        {
                                  if(y<65)
                                  {
            if (!Right_Add_Start)   //�����û�м�¼��ʼ����λ��
            {

                Right_Add_Start = y;    //��¼��߽粹�߿�ʼλ��
            }

            Add_Slope = 1.0*(right_line[Right_Add_Start+6] - right_line[Right_Add_Start+1]) / 4;    //������ʶ���ǰ����ͼ��б��

                if (Add_Slope < 0)  //�޷�
                {
                    Add_Slope = 0;
                }
                temp_r = (char)((y - (Right_Add_Start+1)) * Add_Slope + right_line[Right_Add_Start+1]);//ͨ��б�����㲹�ߵ�λ��
                Right_Last_Slope = Add_Slope;   //��ϸ�ϴ��ұ߽�б��


            Right_Line_New2[y] = range_protect(temp_r, 2, 184);      //��ֱ���޸ı߽磬ֻ�����ڲ���������
          }
                                }
                          if (Left_Add2[y] && Right_Add2[y])  //���߶���Ҫ����
        {
            Width[y] = Right_Line_New2[y] - Left_Line_New2[y];    //���¼��㱾����������

                                 }
        else    //����Ҫ���߻�ֻ��һ����Ҫ����
        {
            if (Left_Add2[y])    //�˴����ֻ��һ�߻���Ҫ����
            {
                Width[y] = right_line[y] - Left_Line_New2[y];    //���¼��㱾����������

                                                }
            else if (Right_Add2[y])
            {
                Width[y] = Right_Line_New2[y] - left_line[y];    //���¼��㱾����������

               }
            else
            {
                Width[y] = right_line[y] - left_line[y];        //���ܻ��и��ţ�Ҳ���¼���һ����������

                                                }
            if (Width[y] < Width_Min)
            {
                Width_Min = Width[y];   //������С��������
            }
                            if (left_line[y] > Foresight_Left)  //������߽����ֵ
            {
                Foresight_Left = left_line[y];
            }
            if (right_line[y] < Foresight_Right)//�����ұ߽���Сֵ
            {
                Foresight_Right = right_line[y];
            }


        }
                 if (y>=30 && Right_Add[y] == 1 && Left_Add[y] == 1) times++;
                  if(abs(right_line[y]-left_line[y])<=1)
                        break;
                  if(image_use[y][center_th[y]]==0)
                        break;
                  if(y<=1)
                    break;
           }
             sousuojieshuhang=y+2;
          Cal_losttimes(sousuojieshuhang);////left_huan_num
         for(y=68;y>20;y--)
       {
         if(Right_Add2[y]==1)
         Right_Add_num++;
         if(Left_Add2[y]==1)
         Left_Add_num++;
       }
         for(y=68;y>48;y--)
       {
         if(Right_Add[y]==1)
         Right_Add_num2++;
         if(Left_Add[y]==1)
         Left_Add_num2++;
       }
         huihuan_num=0;
         huandao_7=0;
      for(x=right_line[68];x>=left_line[68];x--)
        {
          if(white_num_col[x]> 66)
          huihuan_num++;
        }
      zhidao_num=0;
      for(x=118;x>=80;x--)
        {
          if(white_num_col[x]> 68)
              zhidao_num++;
          if(white_num_col[x]>41)
              huandao_7++;
        }

//         curvity_point1 = (uint8)((r_start + sousuojieshuhang) / 2);      //�е�
//
//                if (sousuojieshuhang >=60)
//                {
//                  curvity_point2 = (uint8)(sousuojieshuhang + 1);
//                }
//                else
//                {
//                  curvity_point2 = (uint8)(sousuojieshuhang+1);
//                }
//         curvity_right = process_curvity(right_line[r_start], r_start, right_line[curvity_point1], curvity_point1, right_line[curvity_point2], curvity_point2);
//
//         curvity_point1 = (uint8)((l_start + sousuojieshuhang+1) / 2);      //�е�
//
//                if (sousuojieshuhang >=60)
//                {
//                  curvity_point2 = (uint8)(sousuojieshuhang + 1);
//                }
//                else
//                {
//                  curvity_point2 = (uint8)(sousuojieshuhang+1);
//                }
//         curvity_left = process_curvity(left_line[l_start], l_start, left_line[curvity_point1], curvity_point1, left_line[curvity_point2], curvity_point2);


    /************ʮ�ִ���**************/
       if(l_start>=55||r_start>=55)
       {
         find_leftdown_point(67,15,1);   //1��ʮ��
         find_rightdown_point(67,15,1);
       }
       //find_leftmiddle_point(65,20);
    //   if(flag_find_huan_leftmiddle_point)
     //  {
      //   right_buxian(right_turn_middle[1],right_turn_middle[0],160,68);
      //    flag_find_huan_leftmiddle_point=0;
   //    }

         regression(1,20,68);
         k_left=parameterB;

         regression(2,20,68);
         k_right=parameterB;


     if (!left_huan_num&&!right_huan_num)
    {
        //����ҵ����»������¹յ㣬��ʱ�������������

        //ʱʱע��յ������һ��������+1������ʱҪ����һ����
        if (left_turn_down[0] != 69 || right_turn_down[0] != 69)
        {
            if (left_turn_down[0] != 69 && right_turn_down[0] == 69)//���¹յ���ڶ����¹յ㲻����
            {
                regression(1, left_turn_down[0] - 3, left_turn_down[0] + 2);//����
                trend_of_left = parameterB;
                regression(2, left_turn_down[0] - 3, left_turn_down[0] + 2);//����
                trend_of_right = parameterB;
            }
            else if (right_turn_down[0] != 69 && left_turn_down[0] == 69)    //���¹յ���ڶ����¹յ㲻����
            {
                regression(1, right_turn_down[0] - 3, right_turn_down[0] + 2);//����
                trend_of_left = parameterB;
                regression(2, right_turn_down[0] - 3, right_turn_down[0] + 2);//����
                trend_of_right = parameterB;
            }
            else if (left_turn_down[0] != 69 && left_turn_down[0] != 69)   //���ҹյ������
            {
                regression(1, left_turn_down[0] - 3, left_turn_down[0] + 2);//����
                trend_of_left = parameterB;
                regression(2, right_turn_down[0] - 3, right_turn_down[0] + 2);//����
                trend_of_right = parameterB;
            }
        }
       if((trend_of_left>0&&trend_of_right<0)||(trend_of_left<0&&trend_of_right>0))
             twolines_trend=1;
       else
             twolines_trend=0;

       if ((left_turn_down[0] != 69 && twolines_trend == 1) || (youdiuxianshu >= 15 && left_turn_down[0] != 69))
        {

            findleftdownguai = 1;   //��ʾ�ҵ����¹յ���
        }
        else findleftdownguai = 0;
        if ((right_turn_down[0] != 69 && twolines_trend == 1) || (zuodiuxianshu >= 15 && right_turn_down[0] != 69))
        {

            findrightdownguai = 1;//��ʾ�ҵ����¹յ���
        }
        else findrightdownguai = 0;



//                                     if(findrightdownguai&&right_turn_down[0]<55&&right_turn_down[0]<left_turn_down[0])
//                                         regression(0,right_turn_down[0]+2,68);
//                                  else if(findleftdownguai&&left_turn_down[0]<55&&right_turn_down[0]>left_turn_down[0])
//                                      regression(0,left_turn_down[0]+2,68);
//                                  else
                                  regression(0,58,68);
                                   for (int j = (uint8)68; j >= 1; j--)
                                              {
                                                  int jicun = (int)(parameterB * j + parameterA);
                                                  if (jicun >= 185) jicun = 185;
                                                  else if (jicun <= 0) jicun = 0;
                                                 center_th[j] = (uint8)jicun;

                                              }

                                   for(int y=68;y>0;y--)
                                    {
                                     if(image_use[y][center_th[y]]==0)
                                      {
                                         th_y=center_th[y];
                                        break;
                                      }
                                      else
                                      {
                                     whitenum++;
                                      }
                                    }
        /*************�ҵ����»����¹յ����ϲ�Ԥ�����ߣ�Ȼ����˳��Ԥ����������**************/
                      if (findrightdownguai == 1 || findleftdownguai == 1)
                      {



                                    if (findrightdownguai == 1 && findleftdownguai == 0)//��б��ʮ�֣��������¹յ㣬ȡ���¹յ��µ�������
                                    {
                                         if(!three_cross&&!three_cross1&&!youhuihuan_flag&&!lefthuihuan_flag)//������
                                         {
                                          for (uint8 j = 68; j >= 1; j--)
                                                         {
                                                            //���Ϲյ�
                                                            if ( ((j < (uint8)left_turn_down[0])&&((left_line[j] - left_line[j+3]) >= 10) &&((left_line[j] - left_line[j+2]) >= 10) && ((left_line[j] - left_line[j+1]) >= 10 ))
                                                                && Left_Add[j] == 0 && Left_Add[j - 1] == 0 && Left_Add[j -2] == 0)
                                                            {

                                                                left_turn_up[0] = j-2;//��������û�е�0��
                                                                left_turn_up[1] = left_line[j]-2;
                                                                //��õ���������ȷ��һ���ǲ��Ǳ�������С�����С��˵����ǰ�ϵ�����ʱ�ġ��Ϲյ㡱Ϊ��.
                                                                //���������������ʱ�ġ��Ϲյ㡱Ϊ��.
                                                                if (left_turn_up[0] >= left_turn_down[0])
                                                                {
                                                                    ;
                                                                }
                                                                else break;
                                                            }
                                                        }
                                                        /***�����Ϲյ�***********/
                                                        for (uint8 j = 68; j >= 1; j--)
                                                        {
                                                            if (((j < (uint8)right_turn_down[0])  && right_line[j + 3] - right_line[j] >=10&& right_line[j + 2] - right_line[j] >=10 && right_line[j + 1] - right_line[j] >=10 )
                                                           && (Right_Add[j] == 0 && Right_Add[j - 1] == 0 && Right_Add[j - 2] == 0))
                                                            {
                                                                right_turn_up[0] = j-2 ;
                                                                right_turn_up[1] = right_line[j-2];
                                                                if (right_turn_up[0] >= right_turn_down[0])
                                                                {
                                                                    ;
                                                                }
                                                                else break;
                                                            }
                                                        }
                                               if (right_turn_up[0]>(sousuojieshuhang)&&right_turn_up[0] < right_turn_down[0] &&right_turn_up[0] != 0)
                                              {

                                                  findrightupguai = 1;//��ʾ�ҵ����Ϲյ���

                                              }
                                              if (left_turn_up[0]>(sousuojieshuhang)&&left_turn_up[0] < left_turn_down[0] && left_turn_up[0] != 0)
                                              {

                                                  findleftupguai = 1;//��ʾ�ҵ����Ϲյ���
                                              }

                                                    /*********��ʼ����(�ҵ����¹յ�����Ϲյ�  �� �ҵ����¹յ�����Ϲյ�)*********/
                                                    if ((findrightupguai == 1 && findrightdownguai == 1) || (findrightupguai == 1 && findrightdownguai == 0))
                                                    {

                                                        if (findleftupguai == 1 && findleftdownguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                                                        {
                                                            uint8 start1 = left_turn_down[0] +2 ;
                                                            if (start1 >= 68) start1 = 68;

                                                            uint8 start2 = left_turn_up[0];
                                                            if (start2 >= 68) start2 = 68;

                                                            left_buxian(left_line[start1],start1,left_line[start2],start2);



                                                        }
                                                        else if (findleftupguai == 1 && findleftdownguai == 0)
                                                        {
                                                            uint8 start1 = left_turn_up[0];
                                                            if (start1 >= 68) start1 = 68;

                                                            left_buxian(2,68,left_line[start1],start1);

                                                        }
                                                        //���й�ϵ
                                                        if (findrightdownguai == 1 && findrightupguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                                                        {
                                                            uint8 start1 = right_turn_down[0] +2;
                                                            if (start1 >= 68) start1 = 68;

                                                            uint8 start2 = right_turn_up[0];
                                                            if (start2 >= 68) start2 = 68;
                                                            uint8 end2 = right_turn_up[0];
                                                            right_buxian(right_line[start1],start1,right_line[end2],end2);

                                                        }
                                                        else if (findrightdownguai == 0 && findrightupguai == 1)
                                                        {
                                                            uint8 start1 = right_turn_up[0];
                                                            if (start1 >= 68) start1 = 68;

                                                           right_buxian(184,68,right_line[start1],start1);

                                                        }
                                                     }
                                                 else if(!three_cross&&right_turn_down[0]<60)
                                                     sousuojieshuhang=right_turn_down[0]+1;


                                         }

                                     }
                                        else if (findrightdownguai == 0 && findleftdownguai == 1) //��б��ʮ�֣��������¹յ㣬ȡ���¹յ��µ�������
                                        {
                                                  if(!three_cross&&!three_cross1&&!youhuihuan_flag&&!lefthuihuan_flag)
                                             {
                                                     for (uint8 j = 68; j >= 1; j--)
                                                            {
                                                                //���Ϲյ�
                                                                if ( ((j < (uint8)left_turn_down[0])&&((left_line[j] - left_line[j+3]) >= 10) &&((left_line[j] - left_line[j+2]) >= 10) && ((left_line[j] - left_line[j+1]) >= 10 ))
                                                                    && Left_Add[j] == 0 && Left_Add[j - 1] == 0 && Left_Add[j -2] == 0)
                                                                {

                                                                    left_turn_up[0] = j-2;//��������û�е�0��
                                                                    left_turn_up[1] = left_line[j]-2;
                                                                    //��õ���������ȷ��һ���ǲ��Ǳ�������С�����С��˵����ǰ�ϵ�����ʱ�ġ��Ϲյ㡱Ϊ��.
                                                                    //���������������ʱ�ġ��Ϲյ㡱Ϊ��.
                                                                    if (left_turn_up[0] >= left_turn_down[0])
                                                                    {
                                                                        ;
                                                                    }
                                                                    else break;
                                                                }
                                                            }
                                                            /***�����Ϲյ�***********/
                                                            for (uint8 j = 68; j >= 1; j--)
                                                            {
                                                                if (((j < (uint8)right_turn_down[0])  && right_line[j + 3] - right_line[j] >=10&& right_line[j + 2] - right_line[j] >=10 && right_line[j + 1] - right_line[j] >=10 )
                                                               && (Right_Add[j] == 0 && Right_Add[j - 1] == 0 && Right_Add[j - 2] == 0))
                                                                {
                                                                    right_turn_up[0] = j-2 ;
                                                                    right_turn_up[1] = right_line[j-2];
                                                                    if (right_turn_up[0] >= right_turn_down[0])
                                                                    {
                                                                        ;
                                                                    }
                                                                    else break;
                                                                }
                                                            }
                                                   if (right_turn_up[0]>(sousuojieshuhang)&&right_turn_up[0] < right_turn_down[0] &&right_turn_up[0] != 0)
                                                  {

                                                      findrightupguai = 1;//��ʾ�ҵ����Ϲյ���

                                                  }
                                                  if (left_turn_up[0]>(sousuojieshuhang)&&left_turn_up[0] < left_turn_down[0] && left_turn_up[0] != 0)
                                                  {

                                                      findleftupguai = 1;//��ʾ�ҵ����Ϲյ���
                                                  }

                                                        /*********��ʼ����(�ҵ����¹յ�����Ϲյ�  �� �ҵ����¹յ�����Ϲյ�)*********/
                                                        if ((findleftupguai == 1 && findleftdownguai == 1) || (findleftupguai == 1 && findleftdownguai == 0))
                                                        {

                                                            if (findleftupguai == 1 && findleftdownguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                                                            {
                                                                uint8 start1 = left_turn_down[0] +2 ;
                                                                if (start1 >= 68) start1 = 68;

                                                                uint8 start2 = left_turn_up[0];
                                                                if (start2 >= 68) start2 = 68;

                                                                left_buxian(left_line[start1],start1,left_line[start2],start2);



                                                            }
                                                            else if (findleftupguai == 1 && findleftdownguai == 0)
                                                            {
                                                                uint8 start1 = left_turn_up[0];
                                                                if (start1 >= 68) start1 = 68;

                                                                left_buxian(2,68,left_line[start1],start1);

                                                            }
                                                            //���й�ϵ
                                                            if (findrightdownguai == 1 && findrightupguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                                                            {
                                                                uint8 start1 = right_turn_down[0] +2;
                                                                if (start1 >= 68) start1 = 68;

                                                                uint8 start2 = right_turn_up[0];
                                                                if (start2 >= 68) start2 = 68;
                                                                uint8 end2 = right_turn_up[0];
                                                                right_buxian(right_line[start1],start1,right_line[end2],end2);

                                                            }
                                                            else if (findrightdownguai == 0 && findrightupguai == 1)
                                                            {
                                                                uint8 start1 = right_turn_up[0];
                                                                if (start1 >= 68) start1 = 68;

                                                               right_buxian(184,68,right_line[start1],start1);

                                                            }
                                                         }
                                                      else   if(!three_cross&&left_turn_down[0]<60)
                                                        sousuojieshuhang=left_turn_down[0]+1;
                                                }


                                             }
                            else if (findrightdownguai == 1 && findleftdownguai == 1) //����ʮ�֣��������¹յ�����С���µ������У���ϳ�k��b��������ϳ�Ԥ������
                            {

                                xielv_1eft2=abs(left_line[left_turn_down[0]+5]-left_turn_down[1])+abs(left_line[left_turn_down[0]-5]-left_turn_down[1]);
                                xielv_right2=abs(right_line[right_turn_down[0]+5]-right_turn_down[1])+abs(right_line[right_turn_down[0]-5]-right_turn_down[1]);
                if(
                   whitenum!=0&&whitenum<54&&
                  Left_Add_num2==0&&Right_Add_num2==0&&
                  (!lefthuihuan_flag&&!youhuihuan_flag)&&((left_turn_down[0]>18&&left_turn_down[0]!=69)||(right_turn_down[0]>18&&right_turn_down[0]!=69))&&
                  abs(left_turn_down[0]-right_turn_down[0])<30&&
                  ((xielv_1eft2<30&& xielv_right2<30)||(xielv_1eft2<20&& xielv_right2>30)||(xielv_1eft2>20&& xielv_right2<30))
                   &&xielv_1eft2<50&&xielv_right2<50
                  )
                {
                     xj=left_turn_down[1];//||((xielv_1eft2<20&& xielv_right2>30))
                   xk=right_turn_down[1];//||((xielv_1eft2>30&& xielv_right2<20))
                   xj=range_protect(xj, 2,184);
                   xk=range_protect(xk, 2, 184);

                       for(uint8 j=xj+10;j<=xk-10;j++)
                     {
                         if(white_num_col[j]< white_num_col_min)
                              {
                                white_num_col_min=white_num_col[j];
                               white_num_col_min_line=j;
                              }
                     }

                       if(white_num_col_min_line<=(th_y+15)&&white_num_col_min_line>=(th_y-15))   //10
                           {
                            if(white_num_col_line>(th_y+15)||white_num_col_line<(th_y-15))
                             {

                              cnt3++;

                             }
                        if(cnt3>1)
                        {
                             cnt3=0;
                          if(park_flag!=2&&l_start>=65&&r_start>=65&&!poer_flag&&!por_cnt)//
                          {
                              three_cross = 1;
//                                 uart_putchar(WIRELESS_UART, '6');
//                                 uart_putchar(WIRELESS_UART, '1');
                          }
                        }
                       }
               }

                                        if(!three_cross&&!three_cross1&&!youhuihuan_flag&&!lefthuihuan_flag)
                                        {


                                              for (uint8 j = 68; j >= 1; j--)
                                                {
                                                    //���Ϲյ�
                                                    if ( ((j < (uint8)left_turn_down[0])&&((left_line[j] - left_line[j+3]) >= 10) &&((left_line[j] - left_line[j+2]) >= 10) && ((left_line[j] - left_line[j+1]) >= 10 ))
                                                        && Left_Add[j] == 0 && Left_Add[j - 1] == 0 && Left_Add[j -2] == 0)
                                                    {

                                                        left_turn_up[0] = j-3;//��������û�е�0��
                                                        left_turn_up[1] = left_line[j]-3;
                                                        //��õ���������ȷ��һ���ǲ��Ǳ�������С�����С��˵����ǰ�ϵ�����ʱ�ġ��Ϲյ㡱Ϊ��.
                                                        //���������������ʱ�ġ��Ϲյ㡱Ϊ��.
                                                        if (left_turn_up[0] >= left_turn_down[0])
                                                        {
                                                            ;
                                                        }
                                                        else break;
                                                    }
                                                }
                                                /***�����Ϲյ�***********/
                                                for (uint8 j = 68; j >= 1; j--)
                                                {
                                                    if (((j < (uint8)right_turn_down[0])  && right_line[j + 3] - right_line[j] >=10&& right_line[j + 2] - right_line[j] >=10 && right_line[j + 1] - right_line[j] >=10 )
                                                   && (Right_Add[j] == 0 && Right_Add[j - 1] == 0 && Right_Add[j - 2] == 0))
                                                    {
                                                        right_turn_up[0] = j-3 ;
                                                        right_turn_up[1] = right_line[j-3];
                                                        if (right_turn_up[0] >= right_turn_down[0])
                                                        {
                                                            ;
                                                        }
                                                        else break;
                                                    }
                                                }
                                       if (right_turn_up[0]>(sousuojieshuhang)&&right_turn_up[0] < right_turn_down[0] &&right_turn_up[0] != 0)
                                      {

                                          findrightupguai = 1;//��ʾ�ҵ����Ϲյ���

                                      }
                                      if (left_turn_up[0]>(sousuojieshuhang)&&left_turn_up[0] < left_turn_down[0] && left_turn_up[0] != 0)
                                      {

                                          findleftupguai = 1;//��ʾ�ҵ����Ϲյ���
                                      }

                                            /*********��ʼ����(�ҵ����¹յ�����Ϲյ�  �� �ҵ����¹յ�����Ϲյ�)*********/
                                            if ((findleftupguai == 1 && findleftdownguai == 1) || (findrightupguai == 1 && findrightdownguai == 1) || (findrightupguai == 1 && findrightdownguai == 0) || (findleftupguai == 1 && findleftdownguai == 0))
                                            {

                                                if (findleftupguai == 1 && findleftdownguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                                                {
                                                    uint8 start1 = left_turn_down[0] +2 ;
                                                    if (start1 >= 68) start1 = 68;

                                                    uint8 start2 = left_turn_up[0];
                                                    if (start2 >= 68) start2 = 68;

                                                    left_buxian(left_line[start1],start1,left_line[start2],start2);



                                                }
                                                else if (findleftupguai == 1 && findleftdownguai == 0)
                                                {
                                                    uint8 start1 = left_turn_up[0];
                                                    if (start1 >= 68) start1 = 68;

                                                    left_buxian(2,68,left_line[start1],start1);

                                                }
                                                //���й�ϵ
                                                if (findrightdownguai == 1 && findrightupguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                                                {
                                                    uint8 start1 = right_turn_down[0] +2;
                                                    if (start1 >= 68) start1 = 68;

                                                    uint8 start2 = right_turn_up[0];
                                                    if (start2 >= 68) start2 = 68;
                                                    uint8 end2 = right_turn_up[0];
                                                    right_buxian(right_line[start1],start1,right_line[end2],end2);

                                                }
                                                else if (findrightdownguai == 0 && findrightupguai == 1)
                                                {
                                                    int start1 = right_turn_up[0];
                                                    if (start1 >= 68) start1 = 68;

                                                   right_buxian(184,68,right_line[start1],start1);

                                                }
                                             }
                                        }

                                }



                 }
           }


           if((!left_huan_num&&!right_huan_num)&&(three_cross1||three_cross)&&!youhuihuan_flag&&!lefthuihuan_flag)//
           {


                        if(park_flag==1)
                        {

                                   if(sousuojieshuhang<=15)//&&(white_num_col_min_line<165)
                                    {
                                       if( findrightdownguai)   //�ڶ�Ȧ
                                       right_buxian(white_num_col_min_line,68-white_num_col[white_num_col_min_line],right_turn_down[1],right_turn_down[0]);
                                     else
                                      right_buxian(white_num_col_min_line,68-white_num_col[white_num_col_min_line],right_line[68],68);
                                       for(int ql=68-white_num_col[white_num_col_min_line]+2;ql>=10;ql--)
                                            {
                                               Left_Line_New[ql]=5;
                                               Right_Line_New[ql]=150;
                                            }
                                 sousuojieshuhang=15;

                                    }
                                   else
                                    {
                                      right_buxian(80,5,right_line[68],68);//68  right_buxian(x1,y1,x2,y2,
                                      sousuojieshuhang=15;
                                    }


                           if (r_start<55)//60
                           {
                            three_cross1=1;
//                             uart_putchar(WIRELESS_UART, '6');
//                                             uart_putchar(WIRELESS_UART, '4');

                           }
                           if(three_cross1&&r_start>55)//||white_num_col_line>=130&&white_num_col_min_line>=110
                           {
                               three_cross=0;
                               three_cross1=0;
                               three_cross_cnt++;
                             //  sprintf(uart_buf,"%d          /r/n",three_cross_cnt);
                       //        seekfree_wireless_send_buff(uart_buf, 10);
//                               uart_putchar(WIRELESS_UART, '6');
//                                              uart_putchar(WIRELESS_UART, '5');
//                                                uart_putchar(WIRELESS_UART, ' ');
                           }

                        }
                        else if(park_flag==0)
                        {
                            if(sousuojieshuhang<=15)//&&(white_num_col_min_line>20)
                                     {
                                       if(findleftdownguai)  //��һȦ
                                               left_buxian(white_num_col_min_line,68-white_num_col[white_num_col_min_line],left_turn_down[1],left_turn_down[0]);
                                              else
                                              left_buxian(white_num_col_min_line,68-white_num_col[white_num_col_min_line],left_line[68],68);
                                                  for(int ql=68-white_num_col[white_num_col_min_line]+2;ql>=10;ql--)
                                                               {
                                                                  Right_Line_New[ql]=180;
                                                                  Left_Line_New[ql]=130;
                                                               }

                                              sousuojieshuhang=15;
                                     }
                            else
                                     {
                                      left_buxian(185,15,left_line[68],68);
                                      sousuojieshuhang=15;
                                    }


                           if(l_start<55)
                           {three_cross1=1;
//                           uart_putchar(WIRELESS_UART, '6');
//                                            uart_putchar(WIRELESS_UART, '2');

                           }

                           if(three_cross1&&l_start>55)//&&white_num_col_min_line<70
                            {
                               three_cross_cnt++;
//                               sprintf(uart_buf,"%d          /r/n",three_cross_cnt);
//                               seekfree_wireless_send_buff(uart_buf, 10);
                               three_cross=0;
                               three_cross1=0;
//                               uart_putchar(WIRELESS_UART, '6');
//                                               uart_putchar(WIRELESS_UART, '3');    uart_putchar(WIRELESS_UART, ' ');
                            }

                        }

          }




        //��ʮ����
        if(!youhuihuan_flag&&!lefthuihuan_flag&&!three_cross1&&!three_cross&&(!left_huan_num&&!right_huan_num)&&(l_start<65&&r_start<65&& abs(l_start - r_start) <= 12)&&times>=5)
         {
                  for (uint8 j = 68; j >= 1; j--)
                      {
                          //���Ϲյ�
                          if ( ((j < (uint8)left_turn_down[0])&&((left_line[j] - left_line[j+3]) >= 10) &&((left_line[j] - left_line[j+2]) >= 10) && ((left_line[j] - left_line[j+1]) >= 10 ))
                              && Left_Add[j] == 0 && Left_Add[j - 1] == 0 && Left_Add[j -2] == 0)
                          {

                              left_turn_up[0] = j-2;//��������û�е�0��
                              left_turn_up[1] = left_line[j]-2;
                              //��õ���������ȷ��һ���ǲ��Ǳ�������С�����С��˵����ǰ�ϵ�����ʱ�ġ��Ϲյ㡱Ϊ��.
                              //���������������ʱ�ġ��Ϲյ㡱Ϊ��.
                              if (left_turn_up[0] >= left_turn_down[0])
                              {
                                  ;
                              }
                              else break;
                          }
                      }
                      /***�����Ϲյ�***********/
                      for (uint8 j = 68; j >= 1; j--)
                      {
                          if (((j < (uint8)right_turn_down[0])  && right_line[j + 3] - right_line[j] >=20&& right_line[j + 2] - right_line[j] >=20 && right_line[j + 1] - right_line[j] >=20 )
                         && (Right_Add[j] == 0 && Right_Add[j - 1] == 0 && Right_Add[j - 2] == 0))
                          {
                              right_turn_up[0] = j-2 ;
                              right_turn_up[1] = right_line[j-2];
                              if (right_turn_up[0] >= right_turn_down[0])
                              {
                                  ;
                              }
                              else break;
                          }
                      }
                      if (right_turn_up[0]>(sousuojieshuhang)&&right_turn_up[0] < right_turn_down[0] &&right_turn_up[1] <= right_turn_down[1]&&right_turn_up[0] != 0)
                      {

                          findrightupguai = 1;//��ʾ�ҵ����Ϲյ���

                      }
                      if (left_turn_up[0]>(sousuojieshuhang)&&left_turn_up[0] < left_turn_down[0] &&left_turn_up[1] >= left_turn_down[1]&& left_turn_up[0] != 0)
                      {

                          findleftupguai = 1;//��ʾ�ҵ����Ϲյ���
                      }
                  /*********��ʼ����(�ҵ����¹յ�����Ϲյ�  �� �ҵ����¹յ�����Ϲյ�)*********/
                  if ((findleftupguai == 1 && findleftdownguai == 1) || (findrightupguai == 1 && findrightdownguai == 1) || (findrightupguai == 1 && findrightdownguai == 0) || (findleftupguai == 1 && findleftdownguai == 0))
                  {

                      if (findleftupguai == 1 && findleftdownguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                      {
                          uint8 start1 = left_turn_down[0] +2 ;
                          if (start1 >= 68) start1 = 68;

                          uint8 start2 = left_turn_up[0];
                          if (start2 >= 68) start2 = 68;

                          left_buxian(left_line[start1],start1,left_line[start2],start2);



                      }
                      else if (findleftupguai == 1 && findleftdownguai == 0)
                      {
                          uint8 start1 = left_turn_up[0];
                          if (start1 >= 68) start1 = 68;

                          left_buxian(2,68,left_line[start1],start1);

                      }
                      //���й�ϵ
                      if (findrightdownguai == 1 && findrightupguai == 1)        //�ҵ����¹յ�����Ϲյ�,�������ĵ����¹յ�������������Ϲյ�����������
                      {
                          uint8 start1 = right_turn_down[0] +2;
                          if (start1 >= 68) start1 = 68;
                          uint8 end1 = right_turn_down[0] + 1;
                          uint8 start2 = right_turn_up[0];
                          if (start2 >= 68) start2 = 68;
                          uint8 end2 = right_turn_up[0];
                          right_buxian(right_line[start1],start1,right_line[end2],end2);

                      }
                      else if (findrightdownguai == 0 && findrightupguai == 1)
                      {
                          uint8 start1 = right_turn_up[0];
                          if (start1 >= 68) start1 = 68;
                          uint8 end1 = right_turn_up[0] ;
                         right_buxian(184,68,right_line[start1],start1);

                      }
                   }
           }


     }






void Mid_Line_Repair(uint8 count)
{
           uint8 i;
       for (i = 68; i > count; i--)
        {
           Half_width_handao[i]=Half_width_handao2[i]+huan_bankuan;
           Half_width[i]=Half_width2[i]+com_bankuan;
                               {

                               if(Left_Line_New[i]<=18&&Right_Line_New[i]<184&&!three_cross
                                                        &&right_huan_num!=7&&left_huan_num!=7
                                                        &&right_huan_num!=5&&left_huan_num!=5
                                                        &&right_huan_num!=3&&left_huan_num!=3)

                                                   {
                                                     if(Right_Line_New[i]-Half_width[i]<=18)
                                                     center[i]=18;
                                                     else
                                                         if(     right_huan_num==8||left_huan_num==8||
                                                                 right_huan_num==9||left_huan_num==9||
                                                                 right_huan_num==1||left_huan_num==1||
                                                                 right_huan_num==2||left_huan_num==2||
                                                                 youhuihuan_flag==1||lefthuihuan_flag==1||(huihuan_num>18&&!poer_flag)
                                                        )
                                                     center[i]=Right_Line_New[i]-Half_width_yuanshi[i];//||huihuan_num>15||sousuojieshuhang<=3
                                                     else
                                                     {
                                                      if(right_huan_num!=0||left_huan_num!=0)
                                                        center[i]=  Right_Line_New[i]- Half_width_handao[i];
                                                      else
                                                        center[i] =  Right_Line_New[i]-Half_width[i];
                                                     }
                                                   }
                                                else  if(Left_Line_New[i]>18&&Right_Line_New[i]>=184&&!three_cross
                                                        &&right_huan_num!=7&&left_huan_num!=7
                                                        &&right_huan_num!=5&&left_huan_num!=5
                                                        &&right_huan_num!=3&&left_huan_num!=3)
                                                   {
                                                     if(Left_Line_New[i]+Half_width[i]>=184)
                                                      center[i]=184;
                                                     else
                                                    if(
                                                      right_huan_num==8||left_huan_num==8||
                                                      right_huan_num==9||left_huan_num==9||
                                                      right_huan_num==1||left_huan_num==1||
                                                      right_huan_num==2||left_huan_num==2||
                                                      youhuihuan_flag==1||lefthuihuan_flag==1||(huihuan_num>18&&!poer_flag)
                                                       )
                                                     center[i]=Left_Line_New[i]+Half_width_yuanshi[i];
                                                      else
                                                      {
                                                          if(right_huan_num!=0||left_huan_num!=0)
                                                         center[i]=  Left_Line_New[i]+ Half_width_handao[i];
                                                       else
                                                         center[i] =  Left_Line_New[i]+Half_width[i];
                                                      }
                                                   }
                                                else
                                                      center[i] = ( Left_Line_New[i] + Right_Line_New[i]) / 2;    //���ұ߽綼���޸�����,�õ�����
                                             }
                                             center[i] = range_protect(center[i], 18, 184);//�޷�����

                  }

       /******************************************************************���ʼ���**************************************************************/
       for (i = 60; i > count; i--)
       {

            if((center[y]-center[y+1])>0)
            qulv_jinduan_right++;
            else
            if((center[y]-center[y+1])<0)
            qulv_jinduan_left++;
       }
          //  qvlv_quanju=abs(qvlv_quanju_right-qvlv_quanju_left);//����ȫ��qvlv_quanju qulv_jinduan qulv_yuandaun
            qulv_jinduan=abs(qulv_jinduan_right-qulv_jinduan_left);//���ʽ���
          //  qulv_yuandaun=abs(qulv_yuandaun_right-qulv_yuandaun_left);//����Զ��


            regression(0, sousuojieshuhang+3, 65);
                     k_center=parameterB;
        for (i = 68; i > sousuojieshuhang; i--)
        {
//         image_use[i][left[i]+3] =1;
//          image_use[i][right[i]-3] =2;
          image_use[i][center[i]] =0;
                     image_use[i][Left_Line_New[i]+3] =0;
                      image_use[i][Right_Line_New[i]-3] =0;
                 //     image_use[i][center_th[i]] =0;
        }
}

float Point_Weight(void)
{
                  char i;
                  Sum=0;
        Weight_Count=0;


//   if (Foresight_Left + 42 < Foresight_Right&&!youhuandao_flag&&!zuohuandao_flag)     //λ��ֱ�߻�СS��û���ϰ���
//  {
//          Point = (Foresight_Left + Foresight_Right) / 2; //ȡ���Ҽ�ֵ�е���ΪĿ���
//  }
//                 else
//                 {
   // if(park_flag==1&&j_flag==0) time_flag1=time_flag,j_flag=1;


//
//                    if((left_num+right_num)/2<340)
//                    quanzhi_num=23;
//                else  if((left_num+right_num)/2<355)
//                       quanzhi_num=22;
//                else  if((left_num+right_num)/2<370)
//                       quanzhi_num=20;
//                else  if((left_num+right_num)/2<385)
//                       quanzhi_num=18;
//                else  if((left_num+right_num)/2<430)
//                       quanzhi_num=16;
//                else  if((left_num+right_num)/2<480)
//                       quanzhi_num=15;
//
             if((left_num+right_num)/2<340)
                 quanzhi_num=26;
             else  if((left_num+right_num)/2<360)
                    quanzhi_num=25;
             else  if((left_num+right_num)/2<380)
                    quanzhi_num=23;
             else  if((left_num+right_num)/2<400)
                    quanzhi_num=21;
             else  if((left_num+right_num)/2<420)
                    quanzhi_num=19;
             else  if((left_num+right_num)/2<440)
                    quanzhi_num=18;


                             if(left_huan_num!=0||right_huan_num!=0)
                                         {
                                       if((left_num+right_num)/2<340)
                                                quanzhi_num=23;
                                            else  if((left_num+right_num)/2<360)
                                                   quanzhi_num=22;
                                            else  if((left_num+right_num)/2<380)
                                                   quanzhi_num=21;
                                            else  if((left_num+right_num)/2<400)
                                                   quanzhi_num=20;
                                         }

                for(int i=quanzhi_num;i<quanzhi_num+26;i++)
                {
                    weight_jubu[i]=Weight_jtai[i-quanzhi_num] ;
                }





     // if(park_flag==1&&j_flag==1&&(time_flag-time_flag1)<8)
        if(park_flag==1&&star_lineflag==1)
      {
            //j_flag=1;
          for(int i=0;i<70;i++)
              weight_jubu[i]=Weight_park[i];
      }
       // else
       //  j_flag=0;


//      if(poer_flag)
//      {
//          for(int i=0;i<70;i++)
//        weight_jubu[i]=Weight_park[69-i];
//
//      }
//        else if(left_huan_num!=0||right_huan_num!=0)
//        {
//           for(int i=0;i<70;i++)
//         weight_jubu[i]=Weight_huandao[i];
//        }
//         else  if(lefthuihuan_flag==1||youhuihuan_flag==1)
//         {
//         for(int i=0;i<70;i++)
//         weight_jubu[i]=Weight_huihuan[i];
//         }


//        else  if(lefthuihuan_flag==1||youhuihuan_flag==1)
//        {
//        for(int i=0;i<70;i++)
//        weight_jubu[i]=Weight_huihuan[i];
//        }
//      else
//      {
//          for(int i=0;i<70;i++)
//            weight_jubu[i]=Weight[i];
//      }


//      if((left_num+right_num)/2<340)
//                    quanzhi_num=22;
//                else  if((left_num+right_num)/2<355)
//                       quanzhi_num=21;
//                else  if((left_num+right_num)/2<370)
//                       quanzhi_num=19;
//                else  if((left_num+right_num)/2<385)
//                       quanzhi_num=17;
//                else  if((left_num+right_num)/2<400)
//                       quanzhi_num=15;
//                else  if((left_num+right_num)/2<420)
//                       quanzhi_num=14;
//                else  if((left_num+right_num)/2<440)
//                        quanzhi_num=13;

        if(park_flag==1&&star_lineflag==1)
        {
            for (i = 68; i >=1; i--)        //ʹ�ü�Ȩƽ��
              {

                               Sum += center[i]* weight_jubu[i];
                              Weight_Count += weight_jubu[i];


              }
              Point = Sum /Weight_Count;
                     if(Point>184)
                      Point =184;
                      if(Point<18)
                      Point=18;
        }

        else
        {
                   if(sousuojieshuhang>= 15)
                    {
                               for (i = 68; i >=sousuojieshuhang; i--)        //ʹ�ü�Ȩƽ��
                            {

                                             Sum += center[i]* weight_jubu[i];
                                            Weight_Count += weight_jubu[i];


                            }
                            Point = Sum /Weight_Count;
                                   if(Point>184)
                                    Point =184;
                                    if(Point<18)
                                    Point=18;
                    }
                   else
                                 {
                                              for (i = 68; i >=15; i--)        //ʹ�ü�Ȩƽ��
                                           {

                                                            Sum += center[i]* weight_jubu[i];
                                                           Weight_Count += weight_jubu[i];


                                           }
                                           Point = Sum /Weight_Count;
                                                  if(Point>184)
                                                   Point =184;
                                                   if(Point<18)
                                                   Point=18;
                                   }
        }
                   Point_last3=Point_last2;
                   Point_last2=Point_last1;
                   Point_last1=Point;

                  Point=Point_last1*0.7+Point_last2*0.2+Point_last3*0.1;



                            /***** ʹ����Զ�����ݺ�Ŀ�����Ϊǰհ *****/
        if (sousuojieshuhang <25)
        {
            Point_Mid = center[25];
        }
        else
        {
            Point_Mid = center[sousuojieshuhang+1];
        }



    Foresight = 0.8 * (Point_Mid-91)+ 0.2 *(Point-91);

    return  Point;
}






void jieyahuansuan()
    {
      uint8 y=0;
      for(y=69;y>10;y--)
      {
        image_use[y][left_line[y+4]] =0 ; // 1
        image_use[y][right_line[y-4]] =0; // 3
        image_use[y][center[y]] =0;  //2
      }
    }

uint8 range_protect(uint8 duty, uint8 min, uint8 max)//�޷�����
{
    if (duty >= max)
    {
        return max;
    }
    if (duty <= min)
    {
        return min;
    }
    else
    {
        return duty;
    }
}
int32 range_protect2(int32 duty, int32 min, int32 max)//�޷�����
{
    if (duty >= max)
    {
        return max;
    }
    if (duty <= min)
    {
        return min;
    }
    else
    {
        return duty;
    }
}





void star_line_judg()//�����߼��
    {
    sd_fast=33;
    clc_sd=7;
     baihei_flag=0;
     heibai_flag=0;
      for(kk=left_line[sd_fast-4];kk<=right_line[sd_fast-4];kk++)
      {
        if(image_use[sd_fast][kk]==255)
        {
          bai_flag=1;
          s1=kk;
        }
        else if(bai_flag&&image_use[sd_fast][kk]==0)
        {
          s2=kk;
         if((s2-s1)==1||(s2-s1)==2)
         {
          baihei_flag++;
          bai_flag=0;
         }
         else
          bai_flag=0;
        }

        if(image_use[sd_fast][kk]==0)
        {
          hei_flag=1;
          s3=kk;
        }
        else if(hei_flag&&image_use[sd_fast][kk]==255)
        {
          s4=kk;
          if((s4-s3)==1||(s4-s3)==2)
          {
          heibai_flag++;
          hei_flag=0;
          }
          else
          hei_flag=0;
        }

      }
      if((baihei_flag>=clc_sd&&heibai_flag>=clc_sd))//442
       star_lineflag=1;//�ĳ�1ͣ��
    }

void parkcar()
    {
     //   park_flag = 1;
        leijia_flag=1;
      if(star_lineflag)
      {
             if(c_l==1)
        {
        //  pwm_duty(S_MOTOR_PIN,stree_max);     //���
        }
      else  if(c_l==2)
        {

       //   pwm_duty(S_MOTOR_PIN,stree_min);    //�ұ�
        }
      else  if(c_l==3)
        {
        //  pwm_duty(S_MOTOR_PIN,stree_center);    //�м�
        }

      }
    }



uint8 my_adapt_threshold(uint8 *image, uint16 col, uint16 row)   //ע�������ֵ��һ��Ҫ��ԭͼ��
{
#define GrayScale 256
    uint16 width = col;
    uint16 height = row;
    int pixelCount[GrayScale];
    float pixelPro[GrayScale];
    int i, j, pixelSum = width * height/4;
    uint8 threshold = 0;
    uint8* data = image;  //ָ���������ݵ�ָ��
    for (i = 0; i < GrayScale; i++)
    {
        pixelCount[i] = 0;
        pixelPro[i] = 0;
    }

    uint32 gray_sum=0;
    //ͳ�ƻҶȼ���ÿ������������ͼ���еĸ���
    for (i = 0; i < height; i+=2)
    {
        for (j = 0; j < width; j+=2)
        {
            pixelCount[(int)data[i * width + j]]++;  //����ǰ�ĵ������ֵ��Ϊ����������±�
            gray_sum+=(int)data[i * width + j];       //�Ҷ�ֵ�ܺ�
        }
    }

    //����ÿ������ֵ�ĵ�������ͼ���еı���

    for (i = 0; i < GrayScale; i++)
    {
        pixelPro[i] = (float)pixelCount[i] / pixelSum;

    }

    //�����Ҷȼ�[0,255]
    float w0, w1, u0tmp, u1tmp, u0, u1, u, deltaTmp, deltaMax = 0;


        w0 = w1 = u0tmp = u1tmp = u0 = u1 = u = deltaTmp = 0;
        for (j = 0; j < GrayScale; j++)
        {

                w0 += pixelPro[j];  //��������ÿ���Ҷ�ֵ�����ص���ռ����֮��   ���������ֵı���
                u0tmp += j * pixelPro[j];  //�������� ÿ���Ҷ�ֵ�ĵ�ı��� *�Ҷ�ֵ

               w1=1-w0;
               u1tmp=gray_sum/pixelSum-u0tmp;

                u0 = u0tmp / w0;              //����ƽ���Ҷ�
                u1 = u1tmp / w1;              //ǰ��ƽ���Ҷ�
                u = u0tmp + u1tmp;            //ȫ��ƽ���Ҷ�
                deltaTmp = w0 * pow((u0 - u), 2) + w1 * pow((u1 - u), 2);
                if (deltaTmp > deltaMax)
                {
                    deltaMax = deltaTmp;
                    threshold = j;
                }
                if (deltaTmp < deltaMax)
                {
                break;
                }

         }

    return threshold;

}





void regression(int type, int startline, int endline)
{
    int i = 0;
    int sumlines = endline - startline;
    int sumX = 0;
    int sumY = 0;
    float averageX = 0;
    float averageY = 0;
    float sumUp = 0;
    float sumDown = 0;
    if (type == 0)      //�������
    {
        for (i = startline; i < endline; i++)
        {
            sumX += i;
            sumY += center_th[i];
        }
        if (sumlines != 0)
        {
            averageX = sumX / sumlines;     //x��ƽ��ֵ
            averageY = sumY / sumlines;     //y��ƽ��ֵ
        }
        else
        {
            averageX = 0;     //x��ƽ��ֵ
            averageY = 0;     //y��ƽ��ֵ
        }
        for (i = startline; i < endline; i++)
        {
            sumUp += (center_th[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;
    }
    else if (type == 1)//�������
    {
        for (i = startline; i < endline; i++)
        {
            sumX += i;
            sumY += left_line[i];
        }
        if (sumlines == 0) sumlines = 1;
        averageX = sumX / sumlines;     //x��ƽ��ֵ
        averageY = sumY / sumlines;     //y��ƽ��ֵ
        for (i = startline; i < endline; i++)
        {

            sumUp += (left_line[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;
    }
    else if (type == 2)//�������
    {
        for (i = startline; i < endline; i++)
        {
            sumX += i;
            sumY += right_line[i];
        }
        if (sumlines == 0) sumlines = 1;
        averageX = sumX / sumlines;     //x��ƽ��ֵ
        averageY = sumY / sumlines;     //y��ƽ��ֵ
        for (i = startline; i < endline; i++)
        {
            sumUp += (right_line[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;

    }
}



void check_starting_line()
 {
     //int[] black_nums_stack = new int[20];
     times2 = 0;
     for (uint8 y = 21; y <=29; y++)   //27  32//������ʶ�����ʶ����˾͵�С�㣬ʶ�����˾ʹ�㣩
     {
         black_blocks = 0;
        cursor = 0;    //ָ��ջ�����α�
         for (uint8 x = left_line[35]+5; x <= right_line[35]-5; x++)
         {
             if (image_use[y][x] == 0)
             {
                 if (cursor >= 20)
                 {
                     //����ɫԪ�س���ջ���ȵĲ���   break;
                 }
                 else
                 {
                     cursor++;
                 }
             }
             else
             {
                 if (cursor >= 2 && cursor <= 8)
                 {
                     black_blocks++;
                     cursor = 0;
                 }
                 else
                 {
                     cursor = 0;
                 }
             }
         }
         if (black_blocks >= 3 && black_blocks <= 10) times2++;
     }
     if (times2 >= 3 && times2 <= 9)//6
     {
         star_lineflag = 1;

     }
     else
     {
         star_lineflag = 0;
     }
 }




