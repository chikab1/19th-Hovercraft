/*
 * PID.c
 *
 *  Created on: 2022��5��21��
 *      Author: admin
 */



#include "headfile.h"
float Kp1;      //��̬P
int  Increase_last1=0,Increase_last2=0,Increase1=0,Increase2=0;
float det_Kp;
float det_Ki;
float det_Kd;                    //12, 1, 28,180  MAX16  ˳
PID S_D5_PID, MOTOR_PID,MOTOR2_PID;    //�������͵����PID�����ṹ��//   11, 1, 50,135 �ػ�
int32 S_D5[10][4] = {{14, 0, 55,130},{14, 0, 55,130},{14, 0, 55,130}, {14, 0, 55,130}, {14, 0, 55,130}, {14, 0, 55,130}, {14, 0, 55,130},{14, 0, 55,130},{14, 0, 55,130}, {14, 0, 55,130}};   //���PID

//{ 20, 1, 0, 19}, {24, 2, 15, 28}, {22, 3, 24, 14}, {23, 4, 29, 15}, {25, 5, 21, 14}, {26, 6, 18, 14},},{28, 7, 32, 14} {27,8,35,12};
/* PID �� I ��û��ʹ�ã�ֻ�� PD6�˴� I ����Ϊ�ٶ�ģʽ�ı�ţ���PID��Ӱ�� */
// 4  200       20000 5  1   30    172
//λ��ʽPID������ʼ��

float   MOTOR[3] = {23, 0, 3};    //���PID

//float   MOTOR[3] = {5 , 0.2, 0}; //���PID  18, 0.4
//float   MOTOR2[3] = {5 , 0.2, 0}; //���PID18, 0.4
uint8 BangBang_Flag=0;
void PlacePID_Init(PID *sptr)
{
    sptr->SumError = 0;
    sptr->LastError = 0;    //Error[-1];0
    sptr->PrevError = 0;    //Error[-2]
}
//����ʽPID������ʼ��
void IncPID_Init(PID *sptr)
{
    sptr->SumError = 0;
    sptr->LastError = 0;    //Error[-1]
    sptr->PrevError = 0;    //Error[-2]
    sptr->LastSpeed = 0;
}

//λ��ʽPID�������
int32 PlacePID_Control(PID *sprt, int32 NowPiont, int32 SetPoint)
{
    //����Ϊ�Ĵ���������ֻ���������ͺ��ַ��ͱ�������������ٶ�
    register int32 iError,  //��ǰ���
          Actual, Actual2;   //���ó���ʵ�����ֵ

    iError = NowPiont-SetPoint; //���㵱ǰ���

    Kp1 = 1.0 * (iError*iError) / S_D5[Set][KT] + S_D5[Set][KP]; //Pֵ���ֵ�ɶ��κ�����ϵ//
    if(Kp1>=16)Kp1=16;

      if(left_huan_num!=0||right_huan_num!=0)
    {

          S_D5[Set][KD]=Kp1*(KDD+1)/10.0;//2.1  2.7
    }else
        S_D5[Set][KD]=Kp1*KDD/10.0;//2.1  2.7
    //S_D5[Set][KD]=40;
    Actual = Kp1 * iError + S_D5[Set][KD] * (iError - sprt->LastError);//ֻ��PD
    Actual=Actual/9;
    sprt->LastError = iError;       //�����ϴ����

    Actual2=Actual+stree_center;
                if(Actual2>=stree_max)   Actual2= stree_max;
                if(Actual2<=stree_min)   Actual2 = stree_min;
    return Actual2;
}

//int32 PID_Cascade(PID *sptr, int32 ActualSpeed, int32 SetSpeed)
//{
//    //��ǰ������Ϊ�Ĵ���������ֻ���������ͺ��ַ��ͱ�������������ٶ�
//    register int32 iError,      //��ǰ���
//        Increase;   //���ó���ʵ������
//
//
//    iError = SetSpeed - ActualSpeed;//���㵱ǰ���
//
//    Increase = - MOTOR[KP] * (ActualSpeed - sptr->LastSpeed)    //���ٶ�
//               + MOTOR[KI] * iError
//               + MOTOR[KD] * (iError - 2 * sptr->LastError + sptr->PrevError);\
//    sptr->PrevError = sptr->LastError;  //����ǰ�����
//    sptr->LastError = iError;           //�����ϴ����
//    sptr->LastSpeed = ActualSpeed;      //�����ϴ��ٶ�
//    if (iError < -70)
//    {
//        BangBang_Flag = 1;
//        Increase -= 100;
//    }
//    else if (iError < -50)
//    {
//        BangBang_Flag = 1;
//        Increase -= 70;
//    }
//    else if (iError < -30)
//    {
//        BangBang_Flag = 1;
//        Increase -= 30;
//    }
//
//    if ((iError > 50) && (BangBang_Flag == 1))
//    {
//        BangBang_Flag = 0;
//        Increase +=  150;
//    }
//    else if (iError > 50)
//    {
//        Increase += 100;
//    }
////   if(park_flag==0)
////             {
////
////                         if (iError < -300)
////                        {
////                            Increase -= 1000;
////                        }
////                                      if (iError < -200)
////                        {
////                            Increase -=800 ;
////                        }
////                                    else  if (iError < -100)
////                        {
////                            Increase -= 500;
////                        }
////                                    else if(iError < -70)
////                        {
////                            Increase -= 200;
////                        }
////
////
////                                    else  if (iError >200)
////                        {
////                            Increase += 400;
////                        }
////                                    else if (iError >100)
////                        {
////                            Increase += 200;
////                        }
////               }
////               else if(park_flag==1)
////               {
////                   if (iError < -200)
////                        {
////                            Increase -=10000 ;
////                        }
////                                      if (iError < -100)
////                        {
////                            Increase -=1000 ;
////                        }
////
////               }
//
//
//
///*        if (iError < -100)
//    {
//        Increase -= 200;
//    }
//    else if (iError < -80)
//    {
//        Increase -= 150;
//    }
//    else if (iError < -50)
//    {
//        Increase -= 125;
//    }
//        else if (iError < -30)
//        {
//                Increase -= 100;
//        }*/
//
//    return Increase;
//
//}

int32 PID_Cascade(PID *sptr, int32 ActualSpeed, int32 SetSpeed)
{
    //��ǰ������Ϊ�Ĵ���������ֻ���������ͺ��ַ��ͱ�������������ٶ�
    register int32 iError,iError2,      //��ǰ���
        out;   //���ó���ʵ������


   iError = SetSpeed - ActualSpeed;//���㵱ǰ���  λ��
   iError2=yuzhi_speed-ActualSpeed;

   Increase1 = MOTOR[KP] * (iError) + MOTOR[KD] * (iError - sptr->LastError);







   if(zhidao_flag==1)
      {
                         if (iError2 >70)
                         {
                             BangBang_Flag = 1;
                             Increase2 += 4500;
                         }
                         else if (iError2 >50)
                         {
                             BangBang_Flag = 1;
                             Increase2 += 3500;
                         }
                         else if (iError2 > 30)
                         {
                             BangBang_Flag = 1;
                             Increase2 += 2500;
                         }
                         else if (iError2 > 15)
                         {
                             BangBang_Flag = 1;
                             Increase2 += 1500;
                         }

      }
    else    if(zhidao_flag==2)
    {
       if (iError2 >50)
       {
           BangBang_Flag = 1;
           Increase1 += 400;
       }
       else if (iError2 > 30)
       {
           BangBang_Flag = 1;
           Increase1 += 300;
       }
       else if (iError2 > 15)
       {
           BangBang_Flag = 1;
           Increase1 += 200;
       }

    }
                   if(jisha_flag)
                           {
                              if (iError2 < -70)
                                   {
                                       BangBang_Flag = 1;
                                       Increase1 -= 8000;
                                   }
                                   else if (iError2 < -50)
                                   {
                                       BangBang_Flag = 1;
                                       Increase1 -= 8000;
                                   }
                                   else if (iError2 < -30)
                                   {
                                       BangBang_Flag = 1;
                                       Increase1 -= 8000;
                                   }
                                   else if (iError2 < -15)
                                 {
                                     BangBang_Flag = 1;
                                     Increase1 -= 8000;
                                 }

                           }

                  if(tingche_flag2==1)
                 {
                   if (iError < -70)
                    {
                        BangBang_Flag = 1;
                        Increase1 -= 5000;
                    }
                    else if (iError < -50)
                    {
                        BangBang_Flag = 1;
                        Increase1 -= 4000;
                    }
                    else if (iError < -30)
                    {
                        BangBang_Flag = 1;
                        Increase1 -= 3000;
                    }
                 }
                  else       if(poer_flag==1)
                                   {
                                        if (iError < -70)
                                            {
                                                BangBang_Flag = 1;
                                                Increase1 -= 8500;
                                            }
                                            else if (iError < -50)
                                            {
                                                BangBang_Flag = 1;
                                                Increase1 -= 7500;
                                            }
                                            else if (iError < -30)
                                            {
                                                BangBang_Flag = 1;
                                                Increase1 -= 6000;
                                            }
                                            else if (iError < -15)
                                          {
                                              BangBang_Flag = 1;
                                              Increase1 -= 5000;
                                          }
                                  }



        out=Increase1;
            return out;

}
int32 PID_Cascade2(PID *sptr, int32 ActualSpeed, int32 SetSpeed)
{
    //��ǰ������Ϊ�Ĵ���������ֻ���������ͺ��ַ��ͱ�������������ٶ�
    register int32 iError,iError2,      //��ǰ���
  out;   //���ó���ʵ������


  iError = SetSpeed - ActualSpeed;//���㵱ǰ���  λ��
  iError2=yuzhi_speed-ActualSpeed;

  Increase2 = MOTOR[KP] * (iError) + MOTOR[KD] * (iError - sptr->LastError);
             if(zhidao_flag==1)
               {
                 if (iError2 >70)
              {
                  BangBang_Flag = 1;
                  Increase2 += 4500;
              }
                  else if (iError2 >50)
                  {
                      BangBang_Flag = 1;
                      Increase2 += 3500;
                  }
                  else if (iError2 > 30)
                  {
                      BangBang_Flag = 1;
                      Increase2 += 2500;
                  }
                  else if (iError2 > 15)
                  {
                      BangBang_Flag = 1;
                      Increase2 += 1500;
                  }

               }
             else    if(zhidao_flag==2)
             {
                if (iError2 >50)
                {
                    BangBang_Flag = 1;
                    Increase2 += 400;
                }
                else if (iError2 > 30)
                {
                    BangBang_Flag = 1;
                    Increase2 += 300;
                }
                else if (iError2 > 15)
                {
                    BangBang_Flag = 1;
                    Increase2 += 200;
                }

             }
                        if(jisha_flag)
                       {
                            if (iError2 < -70)
                              {
                                  BangBang_Flag = 1;
                                  Increase2 -= 8000;
                              }
                              else if (iError2 < -50)
                              {
                                  BangBang_Flag = 1;
                                  Increase2 -= 8000;
                              }
                              else if (iError2 < -30)
                              {
                                  BangBang_Flag = 1;
                                  Increase2 -= 8000;
                              }
                              else if (iError2 < -15)
                            {
                                BangBang_Flag = 1;
                                Increase2 -= 8000;
                            }

                }

            if(tingche_flag2==1)
                  {
                    if (iError < -70)
                     {
                         BangBang_Flag = 1;
                         Increase2 -= 5000;
                     }
                     else if (iError < -50)
                     {
                         BangBang_Flag = 1;
                         Increase2 -= 4000;
                     }
                     else if (iError < -30)
                     {
                         BangBang_Flag = 1;
                         Increase2 -= 3000;
                     }
                  }

                        else   if(poer_flag==1)
                               {
                                if (iError < -70)
                                 {
                                     BangBang_Flag = 1;
                                     Increase2 -= 8500;
                                 }
                                 else if (iError < -50)
                                 {
                                     BangBang_Flag = 1;
                                     Increase2 -= 7500;
                                 }
                                 else if (iError < -30)
                                 {
                                     BangBang_Flag = 1;
                                     Increase2 -= 6000;
                                 }
                                 else if (iError < -15)
                                 {
                                     BangBang_Flag = 1;
                                     Increase2 -= 5000;
                                 }
                              }


          out=Increase2;
            return out;
}




//����ʽPID�������
//int32 PID_Realize(PID *sptr, int32 ActualSpeed, int32 SetSpeed)
//{
//    //��ǰ������Ϊ�Ĵ���������ֻ���������ͺ��ַ��ͱ�������������ٶ�
//    register int32 iError,      //��ǰ���
//
//    Increase;   //���ó���ʵ������
//    if (iError < -80)
//                   { MOTOR2[KP]=MOTOR[KP]+6;
//                     MOTOR2[KI]=MOTOR[KI]+1;
//                   }
//                   else if (iError < -60)
//                    { MOTOR2[KP]=MOTOR[KP]+3;
//                      MOTOR2[KI]=MOTOR[KI]+0.7;
//                    }
//                   else if (iError < -40&&zhidao_juli>60)
//                    { MOTOR2[KP]=MOTOR[KP]+3;
//                      MOTOR2[KI]=MOTOR[KI]+0.6;
//                    }
//                    else  if (iError < -20&&zhidao_juli>60)
//                    { MOTOR2[KP]=MOTOR[KP]+3;
//                      MOTOR2[KI]=MOTOR[KI]+0.6;
//                    }
//                    else  if (iError < -20&&zhidao_juli>80)
//                     { MOTOR2[KP]=MOTOR[KP]+3;
//                       MOTOR2[KI]=MOTOR[KI]+0.5;
//                     }
//                    else  if (iError < -10&&zhidao_juli>100)
//                     { MOTOR2[KP]=MOTOR[KP]+3;
//                       MOTOR2[KI]=MOTOR[KI]+0.5;
//                     }
//    iError = SetSpeed - ActualSpeed;//���㵱ǰ���
//    Increase = - MOTOR2[KP] * (ActualSpeed - sptr->LastSpeed)    //���ٶ�
//                  + MOTOR2[KI] * iError
//                  + MOTOR2[KD] * (iError - 2 * sptr->LastError + sptr->PrevError);
////
////    Increase = MOTOR[KP] * (iError - sptr->LastError)
////             + MOTOR[KI] * iError
////             + MOTOR[KD] * (iError - 2 * sptr->LastError + sptr->PrevError);
//
//        sptr->PrevError = sptr->LastError;  //����ǰ�����
//        sptr->LastError = iError;           //�����ϴ����
//        sptr->LastSpeed = ActualSpeed;      //�����ϴ��ٶ�
//
////    if (iError < -70)
////    {
////        BangBang_Flag = 1;
////        Increase -= 100;
////    }
////    else if (iError < -50)
////    {
////        BangBang_Flag = 1;
////        Increase -= 50;
////    }
////    else if (iError < -30)
////    {
////        BangBang_Flag = 1;
////        Increase -= 20;
////    }
////
////    if ((iError > 70) && (BangBang_Flag == 1))
////    {
////        BangBang_Flag = 0;
////        Increase +=  170;
////    }
////    else if (iError > 70)
////    {
////        Increase += 120;
////    }
//
//    return Increase;
//}
////int Turn_Ctl_fuzzy(int point)
////{
////  float turn_err,turn_det;
////  static float turn_err_last;
////  int turn;
////
////  turn_err=point-93;
////  turn_det=turn_err-turn_err_last;
////  turn_err_last=turn_err;
////
////
//////  turn_err=-14.5;
////  turn_det=-3;
//
//  int i,j;
//  /**********������*******/
//  uint8 NB=-6;
//  uint8 NM=-4;
//  uint8 NS=-2;
//  uint8 ZO=0;
//  uint8 PS=2;
//  uint8 PM=4;
//  uint8 PB=6;
//
//
//
//
////  float  eRule[13]={-6.0,-5.0,-4.0,-3.0,-2.0,-1.0,0.0,1.0,2.0,3.0,4.0,5.0,6.0};   //���E��ģ������
////  float  ecRule[7]={-3.0,-2.0,-1.0,0.0,1.0,2.0,3.0}; //���仯��EC��ģ������
//
//  float e=turn_err;
//  float ec=turn_det;
//  float es[7];
//  float ecs[7];
//
//  float menbKp;
//  float menbKi;
//  float menbKd;
//
//  float formKp[7][7],formKi[7][7],formKd[7][7];                  //(��7X7)�������ȱ���
//  float sumKp = 0;                         //�������ķ����н�ģ��,sumΪ��ĸ
//  float sumKi = 0;
//  float sumKd = 0;
//  //ģ�������
//  float FuzzyRuleKp[7][7] = {{PB,PB,PM,PM,PS,ZO,ZO},
//                              {PB,PB,PM,PS,PS,ZO,NS},
//                              {PB,PM,PM,PS,ZO,NS,NS},
//                              {PM,PM,PS,ZO,NS,NM,NM},
//                              {PS,PS,ZO,NS,NS,NM,NB},
//                              {PS,ZO,NS,NM,NM,NM,NB},
//                              {ZO,ZO,NM,NM,NM,NB,NB}};
//
//  /******************����det_Kp*****************/
//
//  //��ƫ��ӻ�������ת������Ӧ��ģ��������
//  if(turn_err>=0)
//  {
//    e=turn_err/(93-2)*3;
//  }
//  else
//  {
//    e=turn_err/(184-93)*3;
//  }
//  //ƫ��仯�ʴӻ�������ת������Ӧ��ģ��������
//  //turn_det_show=turn_det;
//  ec=turn_det/20*3;
//  /********�����ȼ���********************/
//  es[NB] = ufl(e, -3, -1);                       //����1��ƫ��E
//  es[NM] = uf(e, -3, -2, 0);
//  es[NS] = uf(e, -3, -1, 1);
//  es[ZO] = uf(e, -2, 0, 2);
//  es[PS] = uf(e, -1, 1, 3);
//  es[PM] = uf(e, 0, 2, 3);
//  es[PB] = ufr(e, 1, 3);
//
//  ecs[NB] = ufl(ec, -3, -1);                    //����2��ƫ��仯��Ec
//  ecs[NM] = uf(ec, -3, -2, 0);
//  ecs[NS] = uf(ec, -3, -1, 1);
//  ecs[ZO] = uf(ec, -2, 0, 2);
//  ecs[PS] = uf(ec, -1, 1, 3);
//  ecs[PM] = uf(ec, 0, 2, 3);
//  ecs[PB] = ufr(ec, 1, 3);
//  /******ģ������ ����Ŀ��Ŷ�ͨ��ȡС����õ�*****/
//  for (i = 0; i < 7; i++)
//  {
//      float w,h,r;
//      for (j = 0; j < 7; j++)
//      {
//          h = es[i];
//          r = ecs[j];
//          w = fand(h, r);
//          formKp[i][j] = w;
//          sumKp += w;
//       }
//  }
//  /***************************��ģ���������ķ������¼������**********************************/
//    for (i = 0; i < 7; i++)
//    {
//        for (j = 0; j < 7; j++)
//        {
//            if (FuzzyRuleKp[i][j] == NB) {menbKp += (formKp[i][j] * cufl(formKp[i][j], -6, -2));}
//            else if(FuzzyRuleKp[i][j] == NM) {menbKp += (formKp[i][j] * cuf(formKp[i][j], -6, -4, 0));}
//            else if(FuzzyRuleKp[i][j] == NS) {menbKp += (formKp[i][j] * cuf(formKp[i][j], -6, -2, 2));}
//            else if(FuzzyRuleKp[i][j] == ZO) {menbKp += (formKp[i][j] * cuf(formKp[i][j], -4, 0, 4));}
//            else if(FuzzyRuleKp[i][j] == PS) {menbKp += (formKp[i][j] * cuf(formKp[i][j], -2, 2, 6));}
//            else if(FuzzyRuleKp[i][j] == PM) {menbKp += (formKp[i][j] * cuf(formKp[i][j], 0, 4, 6));}
//            else if(FuzzyRuleKp[i][j] == PB) {menbKp += (formKp[i][j] * cufr(formKp[i][j], 2, 6));}
//        }
//    }
//    det_Kp = (menbKp / sumKp);
//
//
//    float FuzzyRuleKd[7][7] = {{PS,NS,NB,NB,NB,NM,PS},
//                              {PS,NS,NB,NM,NM,NS,ZO},
//                              {ZO,NS,NM,NM,NS,NS,ZO},
//                              {ZO,ZO,NS,NS,NS,NS,ZO},
//                              {ZO,ZO,ZO,ZO,ZO,ZO,ZO},
//                              {PB,NS,PS,PS,PS,PS,PB},
//                              {PB,PM,PM,PM,PS,PS,PB}};
///******ģ������ ����Ŀ��Ŷ�ͨ��ȡС����õ�*****/
//    for (i = 0; i < 7; i++)
//    {
//        float w,h,r;
//        for (j = 0; j < 7; j++)
//        {
//            h = es[i];
//            r = ecs[j];
//            w = fand(h, r);
//            formKd[i][j] = w;
//        sumKd += w;
//         }
//    }
///***************************��ģ���������ķ������¼������**********************************/
//    for (i = 0; i < 7; i++)
//    {
//        for (j = 0; j < 7; j++)
//            {
//                    if (FuzzyRuleKd[i][j] == NB) {menbKd += (formKd[i][j] * cufl(formKd[i][j], -6, -2));}
//                    else if(FuzzyRuleKd[i][j] == NM) {menbKd += (formKd[i][j] * cuf(formKd[i][j], -6, -4, 0));}
//                    else if(FuzzyRuleKd[i][j] == NS) {menbKd += (formKd[i][j] * cuf(formKd[i][j], -6, -2, 2));}
//                    else if(FuzzyRuleKd[i][j] == ZO) {menbKd += (formKd[i][j] * cuf(formKd[i][j], -4, 0, 4));}
//                    else if(FuzzyRuleKd[i][j] == PS) {menbKd += (formKd[i][j] * cuf(formKd[i][j], -2, 2, 6));}
//                    else if(FuzzyRuleKd[i][j] == PM) {menbKd += (formKd[i][j] * cuf(formKd[i][j], 0, 4, 6));}
//                    else if(FuzzyRuleKd[i][j] == PB) {menbKd += (formKd[i][j] * cufr(formKd[i][j], 2, 6));}
//            }
//    }
//
//    det_Kd = (menbKd / sumKd);
//
//    turn=stree_center+(int)(turn_err*(S_D5[Set][KP]+det_Kp*10.0f)+turn_det*(S_D5[Set][KD]+det_Kd*30.0f));
//
//                    if(turn>=stree_max)   turn= stree_max;
//                    if(turn<=stree_min)   turn = stree_min;
//   // turn_p_show=turn_p+det_Kp;
//   // turn_d_show=turn_d+det_Kd;
//    return turn;
//}
//
//
//
//
////��˹����������
//float gaussmf(float x,float u,float a)
//{
//   return 0.39894228/a*exp(-(x-u)*(x-u)/(2*a*a));
//}
//
////��˹����������
//float gaussmf_ec(float x,float u)
//{
//   return exp(-(x-u)*(x-u)*2);
//}
//
////�����κ���������
//float cuf_w(float x,float u)
//{
//  if(x>=u&&x<=u+2)
//  {
//   return -0.5*(x-u)+1;
//  }
//  else if(x<u&&x>=u-2)
//  {
//   return 0.5*(x-u)+1;
//  }
//  else
//  {
//    return 0;
//  }
//}
//
///****************�����η�ģ��������(��������ȷ�)**********************/
///**************�������ȣ������Σ�ģ��������***************/
//float uf( float x, float a, float b, float c)
//{
//    if(x<=a)
//        return 0;
//    else if((a<x)&&(x<=b))
//        return (x-a)/(b-a);
//    else if((b<x)&&(x<=c))
//        return (c-x)/(c-b);
//    else if(x>c)
//        return 0;
//     return 0;
//}
///****************�����η�ģ��������(��������ȷ�)**********************/
//float cuf( float x, float a, float b, float c)
//{
//    float y,z;
//    z=(b-a)*x+a;
//    y=c-(c-b)*x;
//    return (y+z)/2;
//}
///*****************����(��)�������� ģ����*******************/
//float ufl( float x, float a, float b)
//{
//    if(x<=a)
//        return 1;
//    else if((a<x)&&(x<=b))
//        return (b-x)/(b-a);
//    else if(x>b)
//        return 0;
//    return 0;
//}
//
///*******************���η�ģ����***********************/
//float cufl( float x, float a, float b)
//{
//    return (b-(b-a)*x);
//}
//
//
///*****************����(��)�������� ģ����*******************/
//float ufr( float x, float a, float b)
//{
//    if(x<=a)
//        return 0;
//    if((a<x)&&(x<b))
//        return (x-a)/(b-a);
//    if(x>=b)
//        return 1;
//      return 0;
//}
///*******************���η�ģ����***********************/
//float cufr( float x, float a, float b)
//{
//    return (b-a)*x +a;
//}
//
////�󽻼�
//float fand(float a,float b)
//{
//  return (a<b)?b:a;
//}
//
//float Abs(float a)
//{
//  if(a>0) return a;
//  else return (0-a);
//
//}
PID2 fuzzy(float e,float ec) // e ��Ŀ��ֵ�ͷ���ֵ����� ec�����仯��(���e��΢��)//FuzzyPidMotor_OpenPwm
{
     float etemp,ectemp;
     float eLefttemp,ecLefttemp;
     float eRighttemp ,ecRighttemp;

     int eLeftIndex,ecLeftIndex;
     int eRightIndex,ecRightIndex;
     PID2      fuzzy_PID;

     etemp = e > 3.0 ? 0.0 : (e < - 3.0 ? 0.0 : (e >= 0.0 ? (e >= 2.0 ? 2.5: (e >= 1.0 ? 1.5 : 0.5)) : (e >= -1.0 ? -0.5 : (e >= -2.0 ? -1.5 : (e >= -3.0 ? -2.5 : 0.0) ))));

     eLeftIndex = (int)e;
     eRightIndex = eLeftIndex;
     eLeftIndex = (int)((etemp-0.5) + 3);        //[-3,3] -> [0,6]
     eRightIndex = (int)((etemp+0.5) + 3);

     eLefttemp =etemp == 0.0 ? 0.0:((etemp+0.5)-e);
     eRighttemp=etemp == 0.0 ? 0.0:( e-(etemp-0.5));

     ectemp = ec > 3.0 ? 0.0 : (ec < - 3.0 ? 0.0 : (ec >= 0.0 ? (ec >= 2.0 ? 2.5: (ec >= 1.0 ? 1.5 : 0.5)) : (ec >= -1.0 ? -0.5 : (ec >= -2.0 ? -1.5 : (ec >= -3.0 ? -2.5 : 0.0) ))));

     ecLeftIndex = (int)((ectemp-0.5) + 3);        //[-3,3] -> [0,6]
     ecRightIndex = (int)((ectemp+0.5) + 3);

     ecLefttemp =ectemp == 0.0 ? 0.0:((ectemp+0.5)-ec);
     ecRighttemp=ectemp == 0.0 ? 0.0:( ec-(ectemp-0.5));

/*************************************��ģ��*************************************/
    fuzzy_PID.Kp = (eLefttemp * ecLefttemp *  fuzzyRuleKp[ecLeftIndex][eLeftIndex]
                    + eLefttemp * ecRighttemp * fuzzyRuleKp[ecRightIndex][eLeftIndex]
                    + eRighttemp * ecLefttemp * fuzzyRuleKp[ecLeftIndex][eRightIndex]
                    + eRighttemp * ecRighttemp * fuzzyRuleKp[ecRightIndex][eRightIndex]);

    fuzzy_PID.Ki =   (eLefttemp * ecLefttemp * fuzzyRuleKi[ecLeftIndex][eLeftIndex]
                    + eLefttemp * ecRighttemp * fuzzyRuleKi[ecRightIndex][eLeftIndex]
                    + eRighttemp * ecLefttemp * fuzzyRuleKi[ecLeftIndex][eRightIndex]
                    + eRighttemp * ecRighttemp * fuzzyRuleKi[ecRightIndex][eRightIndex]);

    fuzzy_PID.Kd = (eLefttemp * ecLefttemp *    fuzzyRuleKd[ecLeftIndex][eLeftIndex]
                    + eLefttemp * ecRighttemp * fuzzyRuleKd[ecRightIndex][eLeftIndex]
                    + eRighttemp * ecLefttemp * fuzzyRuleKd[ecLeftIndex][eRightIndex]
                    + eRighttemp * ecRighttemp * fuzzyRuleKd[ecRightIndex][eRightIndex]);
    return fuzzy_PID;

}


float FuzzyPid_Out(float tar,float cur)  // Ŀ��ֵ , ʵ��ֵ
{
    //float tar = 0,cur = 0;                //Ŀ��ֵ , ʵ��ֵ
    float e = 0;       // ���e ���仯��ec(���e��΢��)  ϵͳ���������� ��һ��Ϊ��
//  static PID pid= {0.6, 0.082, 0.12};      //�����ֵkp��ki��kd
    static PID2 pid= {5.0,0.05,0};//-2.8
    static float sumOUT = 0,pwmOUT=0,old1 = 0,old2 = 0,ec=0;                   //�ۼ�ƫ�� old1 old2
    PID2 OUT = {0, 0, 0};
    e = tar-cur;             //ʵ��ֵ - Ŀ��ֵ
    ec = old1-e;
    OUT = fuzzy(e, ec);      //ģ�����Ƶ���  kp��ki��kd

    pwmOUT = (pid.Kp+OUT.Kp)*e+(pid.Ki+OUT.Ki)*old1+(pid.Kd+OUT.Kd)*old2;
    old2= old1;
    old1 = e;
    sumOUT+=pwmOUT;
    return sumOUT; //�������ֵ
}


