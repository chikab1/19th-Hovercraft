/*
 * control.c
 *
 *  Created on: 2022��5��21��
 *      Author: admin
 */

#include "headfile.h"
#include "isr.h"
uint8 ruku_zuobiao_hang_jubu=0;
uint8 ruku_youbiao_hang_jubu=0;
uint8 ruku_zuobiao_hang=0;
uint8 ruku_youbiao_hang=0;
uint8 ruku_zuobiao_lie=0;
uint8 ruku_youbiao_lie=0;
uint8 zhidao_juli=0;
uint8 chujie=0;
int chasuxisu=330;  //�������ϵ��
float angle=0;
uint8 po=0;
int Max_Speed = 9500;
extern uint8 left_huan_num,right_huan_num;
extern uint8 sousuojieshuhang;//����������
uint8 cnt=0;
float K1 =0.3;//k1Ϊ���ٶȼƼ�����Ƕ�ռ�ı�����Խ��Խ���ٶ�Ӱ�죬С�˶�̬Ч������,��Ϊ3��7 �����ٶȿ�
float Accel_Y,Gyro_Y,Accel_X,Accel_Z;
float K2 =0.027;
uint8 s=0,stop=0,poer_flag2=0,poer_flag=0,poer2=0;
uint8 left_whitenum=0,right_whitenum=0;int8 speed_yingshe=0;
uint8 car_gogogo=0;
/***��������ر���***/
int left_num,right_num,LeftOut,RightOut,left_zheng_ma=0,right_zheng_ma=0,left_fan_ma,right_fan_ma;
int32   MOTOR_Duty=0;
int S_D5_Duty,S_D5_Duty2;
int chasuzuo=0;//������
int chasuyou=0;//������
int por_cnt=0;//������
int32 angle2=0;
float x,j;//������
int32 Target_Speed1=0,Target_Speed2=0;
float piancha;//���ƫ��   ͨ������ͷ���ߴ����õ�
int8 Set=7;
int8 lock_flag=0;
float g_fSpeedControlOutNew=10000;   //pid������ٶ�
float g_fSpeedControlIntegral;   //pid�ٶȻ��ֲ���
float Real_speed=0;//��ʵ�����е��ٶ�
int g_nRightMotorPulseSigma;//�ұ�������
int g_nLeftMotorPulseSigma;//���������
uint8 leijia_flag=0,leijia_flag2=0;//�������ۼӱ�־
int left_leijia=0,right_leijia=0;
int left_leijia2=0,right_leijia2=0,right_leijia_por=0,tingche_leijia_por=0;
int g_fCarSpeed=0;//С��ʵ���ٶ�

uint8 zhongzhi=98;
int tingche_flag=0,tingche_flag2=0;//ͣ����־
int stop_flag=0;//�����ϵ��־


int Set_Speed1=370;
int Set_Speed2=300;
int you_speed=0;
int zuo_speed=0;
int jiasu_part=0;

const uint8 left[70]={
 93,93,93,93,93,92,92,92,92,92
,91,91,91,91,91,90,90,90,90,89
,89,89,89,88,88,88,88,87,87,87
,87,87,86,86,86,86,86,85,85,85
,85,84,84,84,84,83,83,83,83,83
,82,82,82,82,81,81,81,81,80,80
,80,80,80,79,79,79,79,78,78,78
};
const uint8 right[70]
                  ={
93,93,93,93,93,100,101,101,101,102,
102,102,103,103,103,103,104,104,104,105,
105,105,105,106,106,106,107,107,107,108,
108,108,108,109,109,109,109,110,110,110,
110,111,111,111,111,111,112,112,112,112,
113,113,113,113,114,114,114,114,115,115,
115,115,116,116,116,116,117,117,117,117
};






void proess()//��������
    {
          Ostu();
          //my_adapt_threshold(uint8 *image, uint16 col, uint16 row)
    //SignalProcess_grayfine_fill();
          if(car_gogogo==0)
         {

           leijia_flag2=1;
           if(right_num>100||left_num>100)
           {
                  if(c_r==2)//zuo����
                   pwm_duty(ATOM1_CH1_P33_9,stree_max-10);
                else if(c_r==1) //zuo����
                  pwm_duty(ATOM1_CH1_P33_9,stree_min+10);
           }
            dianjiqudong(6000,8200);//6000
         }

         if(car_gogogo)
          {

            po=adc_mean_filter(ADC_0, ADC0_CH8_A8, ADC_12BIT, 2);

                 if(po<=100)
                {
                 poer++;
                if(poer>=3)
                 {
                 time11=0;
                 if(por_cnt==0&&(three_cross_cnt==3))//||three_cross_cnt==1
                 {
                     poer_flag=1;
                     por_cnt++;
//                     uart_putchar(WIRELESS_UART, '9');
//                     uart_putchar(WIRELESS_UART, '1');
//                     uart_putchar(WIRELESS_UART, ' ');
                 }



                 }
                if(poer>10)poer=10;
                }
                else
                 poer=0;
             if(poer_flag)
             {
                 leijia_flag2=1;

         //       three_cross=0;
                star_lineflag=0;
                right_huan_num=0;
                left_huan_num=0;
            }

                  if(star_lineflag==0&&!poer_flag&&three_cross_cnt>=4)//&&sousuojieshuhang<16
                  {
                      check_starting_line();
                      if(star_lineflag==1)
                      {
                          park_flag++;
                             uart_putchar(WIRELESS_UART, '5');//
                             uart_putchar(WIRELESS_UART, '5');
                             uart_putchar(WIRELESS_UART, ' ');
                      }
                      if(park_flag>=2){park_flag=2; }
                  }


                   if(star_lineflag)
                   {
                   three_cross=0;
                   right_huan_num=0;
                   left_huan_num=0;
                   }



                     Center_line_deal();
                     if(tingche_flag)
                     {
                         if((Right_Add_num<=3)&&(Left_Add_num<=3)&&(zuodiuxianshu<=3)&&(youdiuxianshu<=3))
                         { tingche_flag2=1;

                         }


                     }
                     /*********ͼ��������**********/
                     if(park_flag!=2)   //����ͣ��
                     {
                     Ostu();            //��ֵ��
                     you_huihuan();     //�һػ�����
                     zuo_huihuan();     //��ػ�����
                     youhuandao();      //�һ�������
                     zuohuandao();      //�󻷵�����
                     }
                     speed_get();       //�ٶȲ���
                     Mid_Line_Repair(sousuojieshuhang);//ȫ�����߲��������������������������������
                     Point=Point_Weight();  //�����������Ȩ�����õ�������ֵģ��������pid����
                     S_D5_Duty = PlacePID_Control(&S_D5_PID, zhongzhi, Point);

                    //S_D5_Duty=Turn_Ctl_fuzzy(Point);

                    if(park_flag==2)
                    {if(c_r==2)
                      ruku_handle();
                    else if(c_r==1)
                      ruku_handle2();

                    }
                    if(!tingche_flag)
                    pwm_duty(ATOM1_CH1_P33_9, S_D5_Duty);
                    else
                    {
                        if(c_r==2)
                         {
                            if(!tingche_flag2&&tingche_flag&&!(right_num<30||left_num<30))
                              pwm_duty(ATOM1_CH1_P33_9,stree_max-5);//�����
                            else   if(tingche_flag2&&tingche_flag&&!(right_num<30||left_num<30))
                              pwm_duty(ATOM1_CH1_P33_9,stree_max-15);
                            else   if(tingche_flag2&&tingche_flag&&(right_num<30||left_num<30))
                                pwm_duty(ATOM1_CH1_P33_9,stree_center);
                         }
                         else   if(c_r==1)
                         {
                             if(!tingche_flag2&&tingche_flag&&!(right_num<30||left_num<30))
                                 pwm_duty(ATOM1_CH1_P33_9,stree_min+5);//�ҽ���
                           else   if(tingche_flag2&&tingche_flag&&!(right_num<30||left_num<30))
                             pwm_duty(ATOM1_CH1_P33_9,stree_min+15);
                           else   if(tingche_flag2&&tingche_flag&&(right_num<30||left_num<30))
                               pwm_duty(ATOM1_CH1_P33_9,stree_center);
                         }
                    }


                   if(sousuojieshuhang>60&&speed_yingshe<10&&park_flag!=2)
                   {
                       chujie=1;
                   }


             if(time>1000)
             {time=1000;}

             if(time1>1000)
             {time1=1000;}

             if(time11>1000)
             {time11=1000;}

             if(time2>1000)
             {time2=1000;}

             if(time22>1000)
             {time22=1000;}

             if(time3>1000)
             {time3=1000;}

             if(time4>1000)
             {time4=1000;}
             if(time5>2000)
             {time5=2000;}
          }

   }
void GetMotorPulse(void)//����������100ms����һ��
        {
        g_nRightMotorPulseSigma  =  right_zheng_ma - right_fan_ma ;
        g_nLeftMotorPulseSigma  =  left_zheng_ma - left_fan_ma;
        right_zheng_ma=0;
        right_fan_ma=0;
        left_zheng_ma=0;
        left_fan_ma=0;
    }

void SpeedControl(void)//�ٶȿ���
    {
    //if(right_huan_num==0&&left_huan_num==0)





    S_D5_Duty2=(S_D5_Duty-stree_center)*chasuxisu/100;   //xΪ����ϵ��/100
    if(S_D5_Duty2>350)
        S_D5_Duty2=350;
    else if(S_D5_Duty2<=-350)
        S_D5_Duty2=-350;


/***ͣ������***/

      if(c_r==2&&tingche_flag==1)
      {
          S_D5_Duty2=300;
       if(tingche_flag2==1)
       { S_D5_Duty2=100;
         if(right_num<50||left_num<50)
         {
        S_D5_Duty2=0;Set_Speed2=0;
         }
       }
      }
      else  if(c_r==1&&tingche_flag==1)
      {
          S_D5_Duty2=-300;
      if(tingche_flag2==1)
       {
          S_D5_Duty2=-100;
        if(right_num<50||left_num<50)
          {
         S_D5_Duty2=0;Set_Speed2=0;
          }
       }
      }
       /***ͣ�����ֽ���***/

//    if(S_D5_Duty2>=0)
//    {
//    you_speed=Set_Speed2+0.2*S_D5_Duty2;//Set_Speed2
//    zuo_speed=Set_Speed2-S_D5_Duty2;//
//    }
//    else
//    {
//    zuo_speed=Set_Speed2-0.2*S_D5_Duty2;
//    you_speed=Set_Speed2+S_D5_Duty2;//
//    }
      if(!(left_huan_num==3||right_huan_num==3||
           left_huan_num==4||right_huan_num==4||
         left_huan_num==5||right_huan_num==5||
          left_huan_num==6||right_huan_num==6||
          left_huan_num==7||right_huan_num==7
          )&&(lefthuihuan_flag==1||lefthuihuan_flag==2||youhuihuan_flag==1||youhuihuan_flag==2))
            {  if(S_D5_Duty2>=0)
                  {
                  you_speed=Set_Speed2+0.15*S_D5_Duty2;//Set_Speed2  0.3
                  zuo_speed=Set_Speed2-S_D5_Duty2;//
                  }
                  else
                  {
                  zuo_speed=Set_Speed2-0.15*S_D5_Duty2;
                  you_speed=Set_Speed2+S_D5_Duty2;//
                  }
            }
            else
                if((left_huan_num==3||right_huan_num==3||
                        left_huan_num==4||right_huan_num==4||
                      left_huan_num==5||right_huan_num==5||
                       left_huan_num==6||right_huan_num==6||
                       left_huan_num==7||right_huan_num==7
                       )
                        &&!(lefthuihuan_flag==1||lefthuihuan_flag==2||youhuihuan_flag==1||youhuihuan_flag==2))
            {  if(S_D5_Duty2>=0)
                  {
                  you_speed=Set_Speed2+0.2*S_D5_Duty2;//Set_Speed2  0.4
                  zuo_speed=Set_Speed2-S_D5_Duty2;//
                  }
                  else
                  {
                  zuo_speed=Set_Speed2-0.2*S_D5_Duty2;
                  you_speed=Set_Speed2+S_D5_Duty2;//
                  }
            }
                else
                {  if(S_D5_Duty2>=0)
                            {
                            you_speed=Set_Speed2+0.05*S_D5_Duty2;//Set_Speed2  ̫��17���� 0.1
                            zuo_speed=Set_Speed2-S_D5_Duty2;//
                            }
                            else
                            {
                            zuo_speed=Set_Speed2-0.05*S_D5_Duty2;
                            you_speed=Set_Speed2+S_D5_Duty2;//
                            }
                }


    Target_Speed1 = PID_Cascade(&MOTOR_PID,left_num,zuo_speed);//speed_setSet_Speed2//S_D5_Duty2
    Target_Speed2 = PID_Cascade2(&MOTOR2_PID,right_num,you_speed);//S_D5_DutyS_D5_Duty2//S_D5_Duty2
    //Target_Speed1+=PID_Realize(&MOTOR_PID,(left_num+right_num)/2, Set_Speed2);

    if(Target_Speed1>Max_Speed)Target_Speed1=Max_Speed;
    else if(Target_Speed1<-Max_Speed)Target_Speed1=-Max_Speed;

    if(Target_Speed2>Max_Speed)Target_Speed2=Max_Speed;
    else if(Target_Speed2<-Max_Speed)Target_Speed2=-Max_Speed;

                      dianjiqudong(Target_Speed1,Target_Speed2);

    }




void chasu(float x)//�������    ȥѧУ������ϵ��chasuxisu  ԽС����Խ���� ��СΪ1
    {
      if(x>0)
      {
        chasuzuo=MOTOR_Duty*x/chasuxisu;//-
        chasuyou=-0.9*MOTOR_Duty*x/chasuxisu;//+
      }
      else
      {
        chasuyou=MOTOR_Duty*(-x)/chasuxisu;///////+
        chasuzuo=-0.9*MOTOR_Duty*(-x)/chasuxisu;//////-
      }

    }



void dianjiqudong(int speed1,int speed2)//�����������     ȥѧУ�޸�������y1  y2
    {
      if(speed1>=0)
      {
          gpio_set(P21_2, 1);
         pwm_duty(ATOM0_CH1_P21_3,speed1+350);


      }
      else if(speed1<0)
        {
            gpio_set(P21_2, 0);
           pwm_duty(ATOM0_CH1_P21_3,abs(speed1-350));
        }
      if(speed2>=0)
          {

          gpio_set(P21_5, 1);
           pwm_duty(ATOM0_CH2_P21_4,speed2+300);
          }
          else if(speed2<0)
            {
             gpio_set(P21_5, 0);
             pwm_duty(ATOM0_CH2_P21_4,abs(speed2-300));
            }

    }
void read_1Ms_pulse(void)//��������ȡ10ms    ȥѧУ���Լ�ms����
    {
       right_num=gpt12_get(GPT12_T6); //�����������������ֵ��

       left_num=-gpt12_get(GPT12_T4);


        if(leijia_flag2==1)   //�͵���ʱ�������
       {

         right_leijia2+=right_num;
          if(right_leijia2>4300)
          {
          car_gogogo=1;
          time=0;
          }
       }
               if(poer_flag)
                {
                    right_leijia_por+=right_num;
                     if(right_leijia_por>12000)
                              {
                             poer_flag=0;
                               right_leijia_por=0;
                               leijia_flag2=0;
                              }
                }
                else
                    right_leijia_por=0;

                         if( star_lineflag)
                          {
                              tingche_leijia_por+=right_num;
                               if(tingche_leijia_por>10000)
                                {
                                   star_lineflag=0;
                                   tingche_leijia_por=0;
                                }
                          }
                          else
                              tingche_leijia_por=0;




          if(g_fSpeedControlOutNew>=0)   //�ж�����(��) 0
          {
            right_zheng_ma= right_zheng_ma+right_num;
          }
         else             //   (��)
           {
            right_fan_ma=right_fan_ma+right_num;
           }

          gpt12_clear(GPT12_T6);
          gpt12_clear(GPT12_T4);
    }


//float icm_angle(int16 icm_acc_x, int16 icm_acc_z, int16 icm_gyro_y) //��ȡ�����ǽǶ�  �ò���
//{
//
//
//
//      Gyro_Y=icm_gyro_y;
//      Accel_X=icm_acc_x;
//      Accel_Z=icm_acc_z;
//
//                        if(Gyro_Y>32768)  Gyro_Y-=65536;                       //��������ת��  Ҳ��ͨ��shortǿ������ת��
//                        if(Accel_X>32768) Accel_X-=65536;                      //��������ת��
//                        if(Accel_Z>32768) Accel_Z-=65536;                      //��������ת��
//
//                        Accel_Y=atan2(Accel_X,Accel_Z)*180/3.14159265;                 //���ٶȼƼ������
//                        Gyro_Y=Gyro_Y/16.4;    //Angle = gyro * dt   dt�ǲ���ʱ��Խ�̻���ֵԽ׼ȷ
//
//                        angle2 = K1 * Accel_Y+ (1-K1) * (angle2 + Gyro_Y * K2);
//
//
//}

void speed_get()
{


    int y=0;
    left_whitenum=0;
    right_whitenum=0;

//
    if(Set==0)Set_Speed1=560;
  else if(Set==1)Set_Speed1=570;
  else if(Set==2)Set_Speed1=580;
  else if(Set==3)Set_Speed1=590;
  else if(Set==4)Set_Speed1=600;
  else if(Set==5)Set_Speed1=610;
  else if(Set==6)Set_Speed1=620;
  else if(Set==7)Set_Speed1=630;
  else if(Set==8)Set_Speed1=640;
  else if(Set==9)Set_Speed1=650;

//    if(Set==0)Set_Speed1=450;
//  else if(Set==1)Set_Speed1=470;
//  else if(Set==2)Set_Speed1=490;
//  else if(Set==3)Set_Speed1=510;
//  else if(Set==4)Set_Speed1=520;
//  else if(Set==5)Set_Speed1=590;
//  else if(Set==6)Set_Speed1=600;
//  else if(Set==7)Set_Speed1=610;
//  else if(Set==8)Set_Speed1=620;
//  else if(Set==9)Set_Speed1=630;





    for(y=69;y>=0;y--)
    {
      if(image_use[y][left[y]]==0)
      {
        break;
      }
      else
      {
      left_whitenum++;
      }
    }
    for(int y=69;y>=0;y--)
   {
    if(image_use[y][right[y]]==0)
     {
       break;
     }
     else
     {
     right_whitenum++;
     }
   }

    if(left_whitenum<right_whitenum)
        speed_yingshe=left_whitenum;
    else
        speed_yingshe=right_whitenum;
//    if(speed_yingshe-30>=0)
//        speed_yingshe=speed_yingshe-30;
//    else
//        speed_yingshe=0;
   //zhidao_juli= 0.0139*speed_yingshe*speed_yingshe-1.4392*speed_yi ngshe+64.5775;//�������
   // speed_yingshe=whitenum;
   // if(speed_yingshe<=30)speed_yingshe=30;
    zhidao_juli=0.001*(float)speed_yingshe*speed_yingshe*speed_yingshe -0.0603*(float)speed_yingshe*speed_yingshe+1.6174 *(float)speed_yingshe-2.9669;
    if(zhidao_juli<=1)zhidao_juli=1;
    jiasu_part=0.0015854*zhidao_juli*zhidao_juli;  //39
    if(chujie==1||tingche_flag2)
    {
        Set_Speed2=0;
    }
    else if(park_flag==2&&!tingche_flag)
    {
         Set_Speed2=620;
    }
    else if(park_flag==2&&tingche_flag)
    {
         Set_Speed2=320;
    }
    else
    {
                    if(junsu==0)
                    {
                            if(left_huan_num==1||right_huan_num==1)
                            {
                            Set_Speed2=575;
                            }
                            else  if(left_huan_num==2||right_huan_num==2)
                            {
                            Set_Speed2=575-575*0.07;
                            }
                            else  if(left_huan_num==3 )
                            Set_Speed2=575-575*0.07;
                            else  if(right_huan_num==3)
                            Set_Speed2=575-575*0.12;
                            else  if(left_huan_num==4 ||right_huan_num==4||
                            left_huan_num==5 ||right_huan_num==5||
                            left_huan_num==6 ||right_huan_num==6
                            )
                            Set_Speed2=575-575*0.05;
                            //  else  if(left_huan_num==7 ||right_huan_num==7 )
                            //  Set_Speed2=Set_Speed1-Set_Speed1*0.05;
                            else   if(three_cross1||three_cross)
                            {
                            Set_Speed2=Set_Speed1-Set_Speed1*0.05;
                            }

                            else
                            if(poer_flag)//(||star_lineflag&&park_flag==1)
                            Set_Speed2=330;
                            else   if(three_cross_cnt==3)
                            {
                            Set_Speed2=580;
                            }
                            //Set_Speed2=Set_Speed1-Set_Speed1*0.50;
                            else  if(lefthuihuan_flag==1||lefthuihuan_flag==2)
                            Set_Speed2=575-575*0.10;
                            else  if(youhuihuan_flag==1||youhuihuan_flag==2)
                            Set_Speed2=575-575*0.10;
                            else  if(youhuihuan_flag==3)
                            Set_Speed2=575-575*0.15;
                            else  if(lefthuihuan_flag==3)
                            Set_Speed2=575-575*0.2;
                            else
                          Set_Speed2=Set_Speed1-jiasu_part;
                        }
                    else
                                                    {  if(left_huan_num==1||right_huan_num==1)
                                                    {
                                                        Set_Speed2=575;
                                                    }
                                                     else  if(left_huan_num==2||right_huan_num==2)
                                                        {
                                                            Set_Speed2=565-565*0.07;
                                                        }
                                                     else  if(left_huan_num==3 )
                                                     Set_Speed2=565-565*0.09;
                                                     else  if(right_huan_num==3)
                                                     Set_Speed2=565-565*0.12;
                                                      else  if(left_huan_num==4 ||right_huan_num==4||
                                                              left_huan_num==5 ||right_huan_num==5||
                                                              left_huan_num==6 ||right_huan_num==6
                                                              )
                                                      Set_Speed2=575-575*0.05;
                                                    //  else  if(left_huan_num==7 ||right_huan_num==7 )
                                                    //  Set_Speed2=Set_Speed1-Set_Speed1*0.05;
                                                     else   if(three_cross1||three_cross)
                                                     {
                                                           Set_Speed2=Set_Speed1-Set_Speed1*0.05;
                                                     }

                                                     else
                                                            if(poer_flag)//(||star_lineflag&&park_flag==1)
                                                            Set_Speed2=350;
                                                    else   if(three_cross_cnt==3)
                                                        {
                                                      Set_Speed2=590;
                                                                    }
                                                                 //Set_Speed2=Set_Speed1-Set_Speed1*0.50;
                                                    else  if(lefthuihuan_flag==1||lefthuihuan_flag==2)
                                                        Set_Speed2=575-575*0.10;
                                                    else  if(youhuihuan_flag==1||youhuihuan_flag==2)
                                                        Set_Speed2=575-575*0.10;
                                                    else  if(youhuihuan_flag==3)
                                                    Set_Speed2=575-575*0.11;
                                                    else  if(lefthuihuan_flag==3)
                                                    Set_Speed2=600;
                                                    else
                                                        Set_Speed2=Set_Speed1;
                    }
    //   8           5                      3*����
    }
}




void ruku_handle()
{
    uint8 ruku_lie=8;



    for(int i=67;i>=5;i--)
    {
    if(image_use[i][ruku_lie]==0&&image_use[i-1][ruku_lie]==0&&image_use[i-2][ruku_lie]==0&&image_use[i+1][ruku_lie]==255&&image_use[i+2][ruku_lie]==255)
    {
        ruku_zuobiao_hang_jubu=i;
    break;
    }}

    if(ruku_zuobiao_hang_jubu)
    {
    for(int i=ruku_lie;i<170;i+=2)
    {
    if(image_use[ruku_zuobiao_hang_jubu+1][i]==255&&image_use[ruku_zuobiao_hang_jubu+2][i]==255&&image_use[ruku_zuobiao_hang_jubu-1][i]==255&&image_use[ruku_zuobiao_hang_jubu-2][i]==255&&image_use[ruku_zuobiao_hang_jubu][i+1]==255&&image_use[ruku_zuobiao_hang_jubu][i+2]==255)
    {
    ruku_zuobiao_lie=i-3;
    break;
    }}}


    for(int i=ruku_zuobiao_hang_jubu-3;i<70;i++)
    {
        if(image_use[i][ruku_zuobiao_lie]==0&&image_use[i+1][ruku_zuobiao_lie]==255&&image_use[i+2][ruku_zuobiao_lie]==255)
        {
            ruku_zuobiao_hang=i;
            break;
        }
    }

        find_leftdown_point(67,15,1);   //1��ʮ��
        find_rightdown_point(67,15,1);
       if(ruku_zuobiao_lie&&ruku_zuobiao_hang&&ruku_zuobiao_hang>check_line)
        //if(left_turn_down[0]>50&&left_turn_down[0]!=69)
          tingche_flag=1;
}






void ruku_handle2()
{
    uint8 ruku_lie=185;



    for(int i=67;i>=1;i--)
    {
    if(image_use[i][ruku_lie]==0&&image_use[i-1][ruku_lie]==0&&image_use[i-2][ruku_lie]==0&&image_use[i+1][ruku_lie]==255&&image_use[i+2][ruku_lie]==255)
    {
        ruku_youbiao_hang_jubu=i-5;
    break;
    }}

    if(ruku_youbiao_hang_jubu)
    {
    for(int i=ruku_lie;i>10;i--)
    {
    if(image_use[ruku_youbiao_hang_jubu+1][i]==255&&image_use[ruku_youbiao_hang_jubu+2][i]==255&&image_use[ruku_youbiao_hang_jubu-1][i]==255&&image_use[ruku_youbiao_hang_jubu-2][i]==255&&image_use[ruku_youbiao_hang_jubu][i-1]==255&&image_use[ruku_youbiao_hang_jubu][i-2]==255)
    {
    ruku_youbiao_lie=i+5;
    break;
    }}}


    for(int i=ruku_youbiao_hang_jubu;i<70;i++)
    {
        if(image_use[i-1][ruku_youbiao_lie]==0&&image_use[i][ruku_youbiao_lie]==0&&image_use[i+1][ruku_youbiao_lie]==255&&image_use[i+2][ruku_youbiao_lie]==255)
        {
            ruku_youbiao_hang=i;
            break;
        }
    }

      //  find_leftdown_point(67,15,1);   //1��ʮ��
     //   find_rightdown_point(67,15,1);


       if(ruku_youbiao_lie&&ruku_youbiao_hang&&ruku_youbiao_hang>check_line)
        //if(left_turn_down[0]>50&&left_turn_down[0]!=69)
          tingche_flag=1;


}
//left_buxian(uint8 x1,uint8 y1,uint8 x2,uint8 y2);

//right_buxian(uint8 x1,uint8 y1,uint8 x2,uint8 y2);
