/*
 * PID.h
 *
 *  Created on: 2022��5��21��
 *      Author: admin
 */

#ifndef CODE_PID_H_
#define CODE_PID_H_


#include "headfile.h"
#include "common.h"


#define KP 0
#define KI 1
#define KD 2
#define KT 3
 extern   float Kp1;      //��̬P
typedef struct PID
{
    long SumError;  //����ۼ�
    int32 LastError;    //Error[-1]
    int32 PrevError;    //Error[-2]
    int32 LastSpeed;    //Speed[-1]
} PID;

extern PID S_D5_PID, MOTOR_PID,MOTOR2_PID; //�������͵����PID�����ṹ��
extern int32 S_D5[10][4];
//λ��ʽPID������ʼ��
void PlacePID_Init(PID *sptr);

//����ʽPID������ʼ��
void IncPID_Init(PID *sptr);

//λ��ʽPID�������
int32 PlacePID_Control(PID *sprt, int32 NowPiont, int32 SetPoint);

//����ʽ����PID����
int32 PID_Cascade(PID *sptr, int32 ActualSpeed, int32 SetSpeed);
int32 PID_Cascade2(PID *sptr, int32 ActualSpeed, int32 SetSpeed);

//����ʽPID����
int32 PID_Realize(PID *sptr, int32 ActualSpeed, int32 SetSpeed);
int Turn_Ctl_fuzzy(int point);///ģ��pid
float Abs(float a);
float fand(float a,float b);
float cufr( float x, float a, float b);
float ufr( float x, float a, float b);
float cufl( float x, float a, float b);
float ufl( float x, float a, float b);
float cuf( float x, float a, float b, float c);
float uf( float x, float a, float b, float c);
float cuf_w(float x,float u);
float gaussmf_ec(float x,float u);
float gaussmf(float x,float u,float a);
/*******mohu**********/
#define NL   -3
#define NM   -2
#define NS   -1
#define ZE   0
#define PS   1
#define PM   2
#define PL   3

//ע�⣺static PID pid= {0, 0, 0};  ��Ҫ�Լ���ֵ

static const float fuzzyRuleKp[7][7]={
    PL, PL, PM, PM, PS, PS, ZE,
    PL, PL, PM, PM, PS, ZE, ZE,
    PM, PM, PM, PS, ZE, NS, NM,
    PM, PS, PS, ZE, NS, NM, NM,
    PS, PS, ZE, NS, NS, NM, NM,
    ZE, ZE, NS, NM, NM, NM, NL,
    ZE, NS, NS, NM, NM, NL, NL
};

static const float fuzzyRuleKi[7][7]={
    NL, NL, NL, NM, NM, ZE, ZE,
    NL, NL, NM, NM, NS, ZE, ZE,
    NM, NM, NS, NS, ZE, PS, PS,
    NM, NS, NS, ZE, PS, PS, PM,
    NS, NS, ZE, PS, PS, PM, PM,
    ZE, ZE, PS, PM, PM, PL, PL,
    ZE, ZE, PS, PM, PL, PL, PL
};

static const float fuzzyRuleKd[7][7]={
    PS, PS, ZE, ZE, ZE, PL, PL,
    NS, NS, NS, NS, ZE, NS, PM,
    NL, NL, NM, NS, ZE, PS, PM,
    NL, NM, NM, NS, ZE, PS, PM,
    NL, NM, NS, NS, ZE, PS, PS,
    NM, NS, NS, NS, ZE, PS, PS,
    PS, ZE, ZE, ZE, ZE, PL, PL
};

typedef struct{
    float Kp;
    float Ki;
    float Kd;
}PID2;

#define FuzzyPidMotor_OpenPwm 3500 // �������
#define FuzzyPidTarge_Error 0 // Ŀ��ֵ�������

PID2 fuzzy(float e,float ec); // ģ��PID����������
float FuzzyPid_Out(float tar,float cur);  // Ŀ��ֵ , ʵ��ֵ
void motor_Fuzzypid_control(float PID_OUT);

extern float pwmout;
/*****/


#endif /* CODE_PID_H_ */
