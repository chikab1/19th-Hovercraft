/*
 * image_process.h
 *
 *  Created on: 2024��6��4��
 *      Author: admin
 */

#ifndef IMAGE_PROCESS_H_
#define IMAGE_PROCESS_H_

void clear_IMG(void);
void get_image(void);
int limit(int x,int max,int min);
int MIN(int x,int min);
void find_leftline(void);
void find_farleftline(void);
void find_rightline(void);
void find_farrightline(void);
void image_Perspective_Correction(void);
void blur_points(float pts_in[][2], uint8 num, float pts_out[][2], uint8 kernel);
void resample_points(float pts_in[][2], uint8 num1, float pts_out[][2], uint8 num2, float dist);
void local_angle_points(float pts_in[][2], uint8 num, float angle_out[], uint8 dist);
void nms_angle(float angle_in[], uint8 num, float angle_out[], uint8 kernel);
void track_leftline(float pts_in[][2], uint8 num, float pts_out[][2], int approx_num, float dist);
void track_rightline(float pts_in[][2], uint8 num, float pts_out[][2], int approx_num, float dist);
void find_corners(void);

#endif /* IMAGE_PROCESS_H_ */
