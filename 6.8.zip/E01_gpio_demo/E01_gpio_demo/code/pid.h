/*
 * pid.h
 *
 *  Created on: 2024��6��8��
 *      Author: admin
 */

#ifndef PID_H_
#define PID_H_

float Position_PID (float error);

#endif /* PID_H_ */
