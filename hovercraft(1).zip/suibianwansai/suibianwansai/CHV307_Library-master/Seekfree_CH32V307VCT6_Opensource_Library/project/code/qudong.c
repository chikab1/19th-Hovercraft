/*
 * qudong.c
 *
 *  Created on: 2024��3��27��
 *      Author: ����
 */
#include "zf_common_headfile.h"
#include "tuxiangchuli.h"
#include"CAIDAN.h"
#include  "saoxianbuxian.h"
double error_1=0;
double error=0;
double error_2=0;
double error_before=0;
double kp=3050;/////4600
double kd=40;///////10
double ki=0.00;///////0.001
int zonghe=0;
int junzhi=0;
int error_zx=0;
int speed_tj_left=0;
int speed_tj_right=0;
int speed_xf;
int expect_speed_1=1600;
int expect_speed_2=1600;
int expect_speed;
int tingche=0;
int lay=0;
double xf_kp=0.0;
double xf_kd=0;
double a=0.05;
double gz=0.0;
double gz_p=0.01;
float Angle_gz = 0.0;
int encoder_data_2=0;
int slow_r=7;//zbz zuo 60 you 15
float
       I_error = 0,
       I_error_1 = 0,
       I_error_2 = 0,
       Speed_I = 0,
       Speed_D = 0.7,
       Speedout = 0,
       count_all = 0,
       Speed_P = 0.17;
void Control_Speed()
{
  if (bzsignal!=0)//���ϼ���
  {
    expect_speed_1=expect_speed_2-500;
  }
  else
  {
    expect_speed_1=expect_speed_2;
  }
  expect_speed=expect_speed_1-abs(slow_r*error);//�������
  I_error= expect_speed-encoder_data_2;//�����
  Speedout =Speed_P*I_error-Speed_D*abs(I_error-I_error_1);//���
  I_error_1=I_error;
}
void QiFei()
{
    if (tingche==0)
    {
        pwm_set_duty(TIM5_PWM_MAP0_CH2_A1, speed_xf);
        pwm_set_duty(TIM5_PWM_MAP0_CH4_A3, speed_xf);
        pwm_set_duty(TIM4_PWM_MAP1_CH1_D12, speed_tj_right);
        pwm_set_duty(TIM5_PWM_MAP0_CH1_A0, speed_tj_left);
    }
    if (tingche==1)
    {
        pwm_set_duty(TIM4_PWM_MAP1_CH1_D12, 500);
        pwm_set_duty(TIM5_PWM_MAP0_CH1_A0, 500);
        pwm_set_duty(TIM5_PWM_MAP0_CH2_A1, 0);
        pwm_set_duty(TIM5_PWM_MAP0_CH4_A3, 0);
    }
}

void error_cul()
{
    Control_Speed();//�ٶȻ�
    error_before=error;
    error=error_1;
    error=a*error_before +(1-a)*error;
    if (error>45)
    {
        error=45;
    }
    if (error<-45)
    {
        error=-45;
    }
    tft180_show_int(16, 16, error, 5);
    /*************************************�����ٶȻ����������У�����ֱ���ٶ��ȶ�����***************************/
//    speed_tj_left=710+Speedout;
//    speed_tj_right=710+Speedout;
    speed_tj_left=speed_tj-(kp/1000*error)-kd*(error-error_before)+Speedout;
    speed_tj_right=speed_tj+(kp/1000*error)+kd*(error-error_before)+Speedout;
    /*************************************����޷�***************************/
    if (speed_tj_left>920)
    {
        speed_tj_left=920;
    }
    if (speed_tj_right>920)
    {
        speed_tj_right=920;
    }
    if (speed_tj_left<600)
    {
        speed_tj_left=600;
    }
    if (speed_tj_right<600)
    {
        speed_tj_right=600;
    }
    speed_xf=speed_xf_1-abs(error*error)*xf_kp+xf_kd*abs(error-error_before);//������������
    /*************************************����޷�***************************/
    if (speed_xf>speed_xf_1)
    {
        speed_xf=speed_xf_1;
    }
    if (speed_xf<speed_xf_1-50)
    {
        speed_xf=speed_xf_1-50;
    }
    /*****************************������������������һ��ֵ�ҳ�����������Ϊ��ת***************************/
//    if (speed_tj_left>890&&speed_tj_right>890&&garageout_flag==2&&encoder_data_2<30)
//    {
//        tingche=1;
//    }
    if (start==1)
    {
        QiFei();
    }
}
void pinjun_error()//���������
{
    junzhi=zonghe/hangshu;
    if (junzhi>124)
    {
      junzhi=124;
    }
    if (junzhi<5)
    {
      junzhi=5;
    }
    error_1=MT9V03X_W/2-junzhi;
    error_cul();
}

void no_brush_init()
{
    pwm_set_duty(TIM4_PWM_MAP1_CH1_D12, 650);
    pwm_set_duty(TIM5_PWM_MAP0_CH1_A0, 600);
//    pwm_set_duty(TIM5_PWM_MAP0_CH2_A1, 600);
//    pwm_set_duty(TIM5_PWM_MAP0_CH4_A3,600);
}
























