/*
 * saoxianbuxian.c
 *
 *  Created on: 2024��3��2��
 *      Author: ����
 */

#include "zf_common_headfile.h"
#include "tuxiangchuli.h"
#include  "CAIDAN.h"
#include "qudong.h"
int left_down_line=0;
int left_up_line=0;
int right_down_line=0;
int right_up_line=0;
int ld=0;
int lu=0;
int rd=0;
int ru=0;
int dl=0;
int dr=0;
int szhs=0;
int szfwp_l=0;
int szfwp_r=0;
int szwp_no=0;
int sjsj;
int xl_yh;
int line_yh;
int i;
int j;
int lxie=0;
int rxie=0;
int r_guai=100;
int l_guai=100;
/*****************************/
int road_W;
/*****************************���϶���*************************************/
int bzsignal;
int count_black_1;
int count_black;
int bzline=0;
int bz_start=40;
int zhidao_signal=0;
int count_white;
void zhidao()
{
    count_white=0;
    count_black=0;
    count_black_1=0;
    for(i=115;i>60;i--)//���м���������ɫ��
    {
        if(mt9v03x_image[i][60]<Threshold)//����ɨ�������Լ�����
        {
            count_black++;
        }
    }
    for(i=115;i>60;i--)//���м���������ɫ��
    {
        if(mt9v03x_image[i][100]<Threshold)//����ɨ�������Լ�����
        {
            count_black_1++;
        }
    }
    for(i=120;i>5;i--)//���м���������ɫ��
    {
        if(mt9v03x_image[i][80]>Threshold)//����ɨ�������Լ�����
        {
            count_white++;
        }
    }
    if (left_lost_count+right_lost_count<10&&abs(error)<7&&count_black+count_black_1<30&&count_white>113)
    {
        zhidao_signal=1;
    }
    tft180_show_int(80,10,zhidao_signal, 5);
}
void shizi_ban_wp()//ʮ�ַ�����
{
            count_black_1=0;
            for (sjsj = 50; sjsj < MT9V03X_W-2; ++sjsj)//��������ɨ
            {
               if(mt9v03x_image[40][sjsj]<Threshold)
               {
                   count_black_1++;
               }
            }
            for (sjsj = 110; sjsj >2; --sjsj)//��������ɨ
            {
               if(mt9v03x_image[40][sjsj]<Threshold)
               {
                   count_black_1++;
               }
            }
            if (count_black_1<10)
            {
               szwp_no=1;
            }
 }
void fldp()//���¹յ�
{
    left_down_line=100;
    for(i=110;i>=60;i--)
      {
        if(
           abs(leftline[i]-leftline[i+1])<=3&&//��ֵ���Ը���
           abs(leftline[i+1]-leftline[i+2])<=3&&
           abs(leftline[i+2]-leftline[i+3])<=3&&
           abs(leftline[i]-leftline[i-6])>=20)
                {
                    left_down_line=i;
                    ld=1;//��ȡ��������
                    dl=1;
                    break;
                }
      }
}
void frdp()
{
     right_down_line=100;
     for(i=110;i>=60;i--)
     {
         if(
         abs(rightline[i]-rightline[i+1])<=3&&
         abs(rightline[i+1]-rightline[i+2])<=3&&
         abs(rightline[i+2]-rightline[i+3])<=3&&
         abs(rightline[i]-rightline[i-6])>=20)
         {
             right_down_line=i;
             rd=1;
             break;
         }
     }
}
void flup()//���Ϲյ�
{
    left_up_line=25;
    for(i=10;i<=70;i++)
    {
      if(
       abs(leftline[i]-leftline[i-1])<=3&&
       abs(leftline[i-1]-leftline[i-2])<=3&&
       abs(leftline[i-2]-leftline[i-3])<=3&&
       abs(leftline[i]-leftline[i+6])>=20)
        {
            left_up_line=i;
            lu=1;
            break;
        }
    }
}
void frup()
{
    right_up_line=25;
     for(i=10;i<=70;i++)
     {
         if(
         abs(rightline[i]-rightline[i-1])<=3&&
         abs(rightline[i-1]-rightline[i-2])<=3&&
         abs(rightline[i-2]-rightline[i-3])<=3&&
         abs(rightline[i]-rightline[i+6])>=20)
         {
             right_up_line=i;
             ru=1;
             break;
         }
     }
}
void connect_line(uint8 x1,uint8 y1,uint8 x2,uint8 y2)//�����ߺ�����ֱ�Ӱ��������߱�ɱ��ߣ����������д�ģ����ܷ�������������ɵĻ��ߺ����Լ��ģ��ĸ��������
{
}

void rconnect_line(uint8 x1,uint8 y1,uint8 x2,uint8 y2)//�����ߺ�����ֱ�Ӱ��������߱�ɱ��ߣ����������д�ģ����ܷ�������������ɵĻ��ߺ����Լ��ģ��ĸ��������
{
}
double xl_kk(uint8 x1,uint8 y1,uint8 x2,uint8 y2)////��б��
{
    int a,b;
    if(y2<y1)
    {
        a=y2;
        y2=y1;
        y1=a;
    }
    if(x2<x1)
    {
        b=x2;
        x2=x1;
        x1=b;
    }
    float kk;
    kk=(float)(y2 - y1) / (float)(x2- x1);
    return kk;
}
void test_black()//��ɫ����
{
      count_black=0;//��ߺ�ɫ��
      count_black_1=0;
      for(i=MT9V03X_W/2;i>5;i--)//���м���������ɫ��
      {
        if(mt9v03x_image[35][i]<Threshold)//����ɨ�������Լ�����
          {
              count_black++;
          }
      }
      for(j=MT9V03X_W/2;j<MT9V03X_W-5;j++)//���м���������ɫ��
      {
        if(mt9v03x_image[35][j]<Threshold)//����ɨ�������Լ�����
          {
            count_black_1++;//�ұߺ�ɫ��
          }
      }
}


void bizhang()//����
{
    road_width[bz_start]=abs(rightline[bz_start]-leftline[bz_start]);//��·����ɨ��
    road_width[bz_start-10]=abs(rightline[bz_start-10]-leftline[bz_start-10]);//��·����ɨ��
    road_width[bz_start+10]=abs(rightline[bz_start+10]-leftline[bz_start+10]);
        if (round_case==0&&shizi_signal==0&&(abs(road_width[bz_start]-road_width[bz_start-10])>17||abs(road_width[bz_start+10]-road_width[bz_start])>17))//ͨ�����м��·���ȵ�ͻ����Ϊ���ϳ��ж�
        {
            test_black();//ɨ���ɫ��
            if (count_black+count_black_1>90)//���Һ�ɫ����������ֵ
            {
                if(bzsignal==0&&left_lost_count<10&&right_lost_count<10&&count_black>45&&count_black>count_black_1)//�����
                {
                        bzsignal=1;
                        jifenjiaodu=0;
                }
                if(bzsignal==0&&left_lost_count<10&&right_lost_count<10&&count_black_1>45&&count_black_1>count_black)//�ұ߱���
                {
                        bzsignal=3;
                        jifenjiaodu=0;
                }
            }
        }
              if (bzsignal==1&&jifenjiaodu<-14)
              {
                  bzsignal=2;//ʶ�𵽱��Ͻ�������ʼ��������
              }
              if (bzsignal==2&&jifenjiaodu>2)//��߶���С���趨ֵ�ҽǶȻ�������Ϊ���Ͻ������ָ�����ѭ��
              {
                 bzsignal=0;
              }
               if (jifenjiaodu>14&&bzsignal==3)
               {
                   bzsignal=4;
               }
               if (bzsignal==4&&jifenjiaodu<0)
               {
                  bzsignal=0;
               }
               if (bzsignal==1)//ʶ�������
               {
                   bzline=60;//Ĭ�Ϲյ�λ�ã���ֹδʶ�𵽹յ�
                   for (i = 100; i >30; i-=3)
                   {
                       if (abs(leftline[i]-leftline[i+5])>15)//ͨ�����ߵ�ͻ�����ж�·��λ�ã�Ҳ���ǹյ�
                       {
                           bzline=i;
                           break;
                       }
                   }
                   connect_line(leftline[bzline]+30, 40,leftline[bzline]+40, 110);//�����ߣ��ӵ��Ǹ����ָ����Լ�ʵ�������
                   rconnect_line(159, 110,159, 40);//�����ߣ������Ǹ����ָ����Լ�ʵ�������
               }
               if (bzsignal==2)//�̶���Ƿ���
               {
                   connect_line(15, 110, 15, 30);//ͨ���̶����߱���ʵ�̶ֹ����
                   rconnect_line(90, 30, 90, 100);
               }
               if (bzsignal==3)
               {
                   bzline=100;
                   for (i = 100; i >30; i-=3)
                   {
                       if (abs(rightline[i]-rightline[i+5])>15)
                       {
                           bzline=i;
                           break;
                       }
                   }
                   rconnect_line(rightline[bzline]-70, 40,rightline[bzline]-70, 110);
                   connect_line(1, 110,1, 40);
               }
               if (bzsignal==4)
               {
                   connect_line(70, 110, 70, 30);
                   rconnect_line(145, 30, 145, 100);
               }
}
void shizi_pd()//ʮ��
{
    if (shizi_lost_count>35&&round_case==0&&bzsignal==0)
    {
        lxie=0;//б���־λ
        rxie=0;
        if (shizi_signal==0)
        {
            shizi_ban_wp();//��ֹ����
            if (szwp_no==1)
            {
                shizi_signal=1;
            }
        }
        if (shizi_signal==1)
        {

                frdp();//�ҹյ�
                fldp();
                frup();
                flup();
                test_black();
                if (leftline[15]/2+leftline[20]/2>90||leftline[30]/2+leftline[35]/2>90||leftline[40]/2+leftline[50]/2>90||count_black_1-count_black>25)
                {
                    rxie=1;//�ж�Ϊ��б��
                }
                if (rightline[15]/2+rightline[20]/2<60||rightline[30]/2+rightline[35]/2<60||rightline[50]/2+rightline[40]/2<60||count_black-count_black_1>25)
                {
                    lxie=1;//�ж�Ϊ��б��
                }
                if (lu==1&&ru==1&&rxie==0&&lxie==0)//�ҵ��Ϲյ������
                {
                    connect_line (leftline[left_down_line],left_down_line,leftline[left_up_line],left_up_line);
                    rconnect_line (rightline[right_down_line],right_down_line,rightline[right_up_line],right_up_line);
                    if (start==0)
                    {
                        tft180_draw_line(rightline[right_down_line],right_down_line,rightline[right_up_line],right_up_line, RGB565_YELLOW);
                    }
                    if (start==0)
                    {
                        tft180_draw_line(leftline[left_down_line],left_down_line,leftline[left_up_line],left_up_line, RGB565_YELLOW);
                    }
                }
                if (rxie==1&&lxie==0)//б�봦��
                {
                    right_up_line=40;
                    for(i=110;i>=20;i--)
                    {
                        if(mt9v03x_image[i][70]<Threshold)
                        {
                             right_up_line=i;
                             break;
                        }
                    }
                    rconnect_line (130,right_up_line,130,110);
                }
                if (lxie==1&&rxie==0)
                {
                    left_up_line=40;
                    for(i=110;i>=20;i--)
                    {
                        if(mt9v03x_image[i][90]<Threshold)
                        {
                             left_up_line=i;
                             break;
                        }
                    }
                    connect_line (35,left_up_line,35,110);

                }
            }
        }
}
void yuanhuan()//Բ����̫�������ü�ע�ͣ��Լ����
{
    tft180_show_int(100, 40, count_white, 5);
    if ((round_case==1||round_case==2||round_case==8||round_case==9)&&right_lost_count<5&&left_lost_count<5&&shizi_lost_count<10)
    {
        round_case=0;
    }
    count_black=0;
    count_black_1=0;
    for(i=115;i>60;i--)//���м���������ɫ��
    {
        if(mt9v03x_image[i][158]<Threshold)//����ɨ�������Լ�����
        {
            count_black++;
        }
    }
    for(i=115;i>60;i--)//���м���������ɫ��
    {
        if(mt9v03x_image[i][2]<Threshold)//����ɨ�������Լ�����
        {
            count_black_1++;
        }
    }
    if (bzsignal==0&&shizi_signal==0&&right_lost_count>35&&round_case==0&&left_lost_count<20&&shizi_lost_count<20)///45 60
    {
       for (i = 90; i >50; --i)
       {
           if (mt9v03x_image[i-2][rightline[i]]>Threshold&&
               mt9v03x_image[i+2][rightline[i]+2]<Threshold&&
               mt9v03x_image[i][rightline[i]+1]<Threshold&&
               mt9v03x_image[i][rightline[i]+5]>Threshold)
           {
               if (rightline[i-2]-rightline[i]>20)
               {
                   round_case=1;
                   r_guai=i;
                   break;
               }
           }
       }
    }
    if (round_case==1)
     {
        xl_yh=0;
        jifenjiaodu=0;
        frdp();
        frup();
        if (rd==1&&ru==1)
        {
            rconnect_line (rightline[right_down_line],right_down_line,rightline[right_up_line],right_up_line-10);
        }
        else
        {
           rconnect_line (125,110,125,20);
        }
     }
    if (round_case==1&&count_black<10)
    {
        round_case=2;
    }
    if (round_case==2&&count_black>20)
    {
        round_case=3;
    }
    if (round_case==3)
    {
        for (i = 70; i >15; --i)
        {
                if (rightline[i+3]-rightline[i]>15)
                {
                    round_case=4;
                    r_guai=i;
                    break;
                }
        }
    }
    if (round_case==4)
    {
        for (i = 70; i >15; --i)
        {
                if (rightline[i+2]-rightline[i]>15)
                {
                    r_guai=i;
                    break;
                }
        }
        if (rightline[r_guai]<150)
        {
            connect_line (30,120,rightline[r_guai]+5,r_guai-10);
        }
        else
        {
            connect_line (30,120,130,30);
        }
                if (jifenjiaodu<-30)
                {
                    round_case = 5;
                }
    }
    if (round_case==5&&jifenjiaodu<-230)
    {
        for (i = 110; i >60; --i)
        {
                if (leftline[i-5]-leftline[i]<-15)
                {
                    l_guai=i;
                    break;
                }
        }
        if (leftline[l_guai]>10)
        {
            connect_line (80,30,leftline[l_guai],l_guai);
        }
        else
        {
            connect_line (80,30,30,110);
        }
    }
    if (round_case==5&&jifenjiaodu<-340)
    {
        round_case=6;
    }
    if (round_case==6&&count_black<5)
    {
        round_case =7;
    }
    if (round_case==7)
    {

       rconnect_line (125,110,125,10);

    }
    if (round_case==7&&count_black>35)
    {
        round_case = 0;
    }
        tft180_show_int(80,60,round_case, 5);

        if (shizi_signal==0&&left_lost_count>35&&right_lost_count<20&&round_case==0&&shizi_lost_count<20)
        {
            for (i = 90; i >30; --i)
            {
                if (mt9v03x_image[i-2][leftline[i]]>Threshold&&
                    mt9v03x_image[i+2][leftline[i]-2]<Threshold&&
                    mt9v03x_image[i][leftline[i]-1]<Threshold&&
                    mt9v03x_image[i][leftline[i]-5]>Threshold)
                {
                    if (leftline[i]-leftline[i-2]>25)
                    {
                        round_case=8;
                        l_guai=i;
                        break;
                    }
                }
            }
         }
           if (round_case==8)
           {
               xl_yh=0;
               jifenjiaodu=0;
               fldp();
               flup();
               if (ld==1&&lu==1)
               {
                   connect_line (leftline[left_down_line],left_down_line,leftline[left_up_line],left_up_line);
               }
               else
               {
                  connect_line (30,110,30,30);
               }
           }
           if (round_case==9&&count_black_1>45&&left_lost_count<20)
           {
               round_case=10;
           }
           if (round_case==10)
           {
               for (i = 70; i >15; --i)
               {
                   if (mt9v03x_image[i-2][leftline[i-2]]<Threshold&&
                       mt9v03x_image[i+2][leftline[i]+2]>Threshold)
                   {
                       if (leftline[i-2]-leftline[i]>10)
                       {
                           round_case=11;
                           l_guai=i;
                           break;
                       }
                   }
               }
           }
           if (round_case==11)
           {
               for (i = 70; i >15; --i)
               {
                   if (mt9v03x_image[i-2][leftline[i-2]]<Threshold&&
                       mt9v03x_image[i+2][leftline[i]+2]>Threshold)
                   {
                       if (leftline[i]-leftline[i+2]>10)
                       {
                           l_guai=i;
                           break;
                       }
                   }
               }
               if (leftline[l_guai]>20)
               {
                   rconnect_line (120,120,leftline[l_guai],l_guai);
               }
               else
               {
                   rconnect_line (120,120,30,30);
               }
               if (jifenjiaodu>30)
               {
                   round_case = 12;
               }
           }
       if (round_case==12&&jifenjiaodu>250)
       {
           for (i = 110; i >60; --i)
           {
                   if (rightline[i-5]-rightline[i]>15)
                   {
                       r_guai=i;
                       break;
                   }
           }
           if (rightline[r_guai]<150)
           {
               rconnect_line (80,30,rightline[r_guai],r_guai);
           }
           else
           {
               rconnect_line (80,30,130,100);
           }
       }
       if (round_case==12&&jifenjiaodu>315)
       {
          round_case=13;
       }
       if (round_case==13&&count_black_1<20&&left_lost_count>30)
       {
          round_case=14;
       }
       if (round_case==14)
       {

              connect_line (50,110,50,10);
       }
       if (round_case==14&&count_black_1>35)
       {
           round_case = 0;
       }
}

void daolukuandu(int8 a,int8 b)
{
    for (int j = a; j < b; j+=5)
    {
        road_width[j]=abs(rightline[j]-leftline[j]);
        road_W+=road_width[j];
    }
}
