/*
 * saoxianbuxian.h
 *
 *  Created on: 2024��3��2��
 *      Author: ����
 */

#ifndef SAOXIANBUXIAN_H_
#define SAOXIANBUXIAN_H_
int find_left_down_point(int start,int end);
int find_left_up_point(int start,int end);
int find_right_down_point(int start,int end);
int find_right_up_point(int start,int end);
int Monotonicity_Change_Left(int start,int end);
extern int left_down_line;
extern int left_up_line;
extern int right_down_line;
extern int right_up_line;
extern int monotonicity_change_line;
extern int ld;
extern int lu;
extern int rd;
extern int ru;
extern int dl;
extern int dr;
extern int bzsignal;
extern int szwp_no;
extern int count_black;
extern int count_black_1;
extern int sjsj;
extern int road_W;
extern int xl_yh;
extern int line_yh;
extern int zhidao_signal;
void fldp();
void frup();
void flup();
void frdp();
void shizi_pd();
void rconnect_line();
void connect_line();
double xl_kk();
int regression();
void test_black();
void bizhang();
void yuanhuan();
void shizi_ban_wp();
void daolukuandu();
#endif /* SAOXIANBUXIAN_H_ */
