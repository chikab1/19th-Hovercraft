/*
 * qudong.h
 *
 *  Created on: 2024��3��27��
 *      Author: ����
 */

#ifndef QUDONG_H_
#define QUDONG_H_

extern double error;
extern double kp;
extern double kd;
extern int zonghe;
extern double xf_kp;
extern double xf_kd;
extern float Angle_gz;
extern double gz_p;
extern int tingche;
extern int encoder_data_2;
extern int expect_speed_1;
extern int lay;
extern int expect_speed_2;
extern float
            Speed_I,
            Speed_P;
extern int slow_r;
/************************��������********************/
void Control_Speed();
void pinjun_error();
void QiFei();
void no_brush_init();
#endif /* QUDONG_H_ */
