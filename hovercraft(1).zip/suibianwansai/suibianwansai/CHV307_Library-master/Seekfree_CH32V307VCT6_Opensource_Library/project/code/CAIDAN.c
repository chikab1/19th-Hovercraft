/*
 * CAIDAN.c
 *
 *  Created on: 2024��3��26��
 *      Author: ����
 */
#include "zf_common_headfile.h"
#include "CAIDAN.h"
#include "qudong.h"
#include "tuxiangchuli.h"
#include "saoxianbuxian.h"
int n=0;
int nn=0;
int nnn=0;
int nnnn=0;
int speed_tj=700;
int speed_xf_1=720;
int chasu=0;
int ye=1;
int start=0;
float jifenjiaodu=0;
uint8 shang_;
uint8 xia_;
uint8 jia_;
uint8 jian_;
uint8 fanhui_;
uint8 queren_;

 int fanye()//��ҳ��ȷ����ǰ����һ�����������
 {
     queren_ = gpio_get_level(queren);
     if(queren_==0)
     {
         system_delay_ms(200);
         tft180_clear();
         ye=2;
     }
     fanhui_ = gpio_get_level(fanhui);
     if(fanhui_==0)
     {
          system_delay_ms(200);
          tft180_clear();
          ye=1;
     }
      return ye;
 }
 void show_string()//��ʾ�ַ�
 {
     tft180_show_string(16,0,"speed");
     tft180_show_string(16,16,"kaiguan");
     tft180_show_string(16,32,"camera");
     tft180_show_string(16,48,"pd");
     tft180_show_string(16,64,"tly");
 }
void jiantou(void)//��ͷ
{
    shang_= gpio_get_level(shang);//��ȡ���ŵ�ƽ
    if (shang_==0)
              {
        system_delay_ms(200);
              n+=16;
              tft180_clear();
                }
    xia_ = gpio_get_level(xia);
        if (xia_==0)
              {
            system_delay_ms(200);
                n-=16;
                tft180_clear();
              }
        if(n>80)  {n=0;}
        if(n<0)  {n=80;}
        tft180_show_string(0, n, "->");

}
void erji()
{
        switch(n)
        {
            case 0://�ٶȿ���
            {
                shang_= gpio_get_level(shang);//��ȡ���ŵ�ƽ
                    if (shang_==0)
                    {
                       system_delay_ms(200);
                       nn+=16;
                       tft180_clear();
                    }
                xia_ = gpio_get_level(xia);
                    if (xia_==0)
                    {
                       system_delay_ms(200);
                       nn-=16;
                       tft180_clear();
                    }
                        if(nn>32)  {nn=0;}
                        if(nn<0)  {nn=32;}
                        tft180_show_string(0, nn, "->");
     /*-----------------------------------��ͷ------------------------------------*/
                   switch (nn) {
                    case 0:
                        jia_ = gpio_get_level(jia);
                  if(jia_==0)
                        { system_delay_ms(200);
                          expect_speed_2+=10;
                        }
                  jian_ = gpio_get_level(jian);
                        if(jian_==0)
                        { system_delay_ms(200);
                          expect_speed_2-=10;
                        }

                        break;
                    case 16:
                        jia_ = gpio_get_level(jia);
                  if(jia_==0)
                        { system_delay_ms(200);
                            speed_xf_1+=10;
                        }
                  jian_ = gpio_get_level(jian);
                        if(jian_==0)
                        { system_delay_ms(200);
                            speed_xf_1-=10;
                        }
                        break;
                    case 32:
                  jia_ = gpio_get_level(jia);
                        if(jia_==0)
                        { system_delay_ms(200);
                          chasu+=3;
                        }
                  jian_ = gpio_get_level(jian);
                        if(jian_==0)
                         { system_delay_ms(200);
                           chasu-=3;
                         }
                }

                tft180_show_string(16, 0, "speed");
                tft180_show_uint(80, 0, expect_speed_2, 5);
                tft180_show_string(16, 16, "speed_xf");
                tft180_show_uint(80, 16, speed_xf_1, 5);
                tft180_show_string(16, 32, "chasu");
                tft180_show_int(80, 32, chasu, 5);
                break;
            }
            case 16://�������
            {
                queren_ = gpio_get_level(queren);
                if (queren_==0)
                {
                    start=1;
                }
                if (start==1)
                {
                    pwm_set_duty(TIM4_PWM_MAP1_CH1_D12, 730);
                    pwm_set_duty(TIM5_PWM_MAP0_CH1_A0, 730);
                    pwm_set_duty(TIM5_PWM_MAP0_CH2_A1, 770);
                    pwm_set_duty(TIM5_PWM_MAP0_CH4_A3, 770);
                }
                break;
            }
            case 32://ͼ��ʶ��
            {
                otsuThreshold(mt9v03x_image[0], 160,128, 10);
                bianjiepanduan();
                if (start==0)
                {
                tft180_show_gray_image(0, 0, mt9v03x_image[0], MT9V03X_W, MT9V03X_H,160, 128,0);
                }
                jian_ = gpio_get_level(jian);
                if (jian_==0)
                {
                    system_delay_ms(100);
                    no_brush_init();
                    gpio_high(C13);
                    system_delay_ms(100);
                    gpio_low(C13);
                    system_delay_ms(1000);
                }
                queren_ = gpio_get_level(queren);
                if (queren_==0)
                {
                    start=1;
                }
                break;
            }
            case 48://kp����
            {
                shang_= gpio_get_level(shang);//��ȡ���ŵ�ƽ
                if (shang_==0)
                {
                    system_delay_ms(200);
                    nnn+=16;
                    tft180_clear();
                }
                xia_ = gpio_get_level(xia);
                if (xia_==0)
                {
                    system_delay_ms(200);
                    nnn-=16;
                    tft180_clear();
                }
                if(nnn>104)  {nnn=0;}
                if(nnn<0)  {nnn=104;}
                tft180_show_string(0, nnn, "->");
    /*-----------------------------------��ͷ------------------------------------*/
                switch (nnn)
                {
                     case 0:
                     jia_ = gpio_get_level(jia);
                     if(jia_==0)
                     {
                         system_delay_ms(200);
                         kp+=100;
                     }
                     jian_ = gpio_get_level(jian);
                     if(jian_==0)
                     {
                         system_delay_ms(200);
                         kp-=100;
                     }
                     break;
                     case 16:
                     jia_ = gpio_get_level(jia);
                     if(jia_==0)
                     {
                         system_delay_ms(200);
                         gz_p+=0.01;
                     }
                     jian_ = gpio_get_level(jian);
                     if(jian_==0)
                     {
                         system_delay_ms(200);
                         gz_p-=0.01;
                     }
                     break;
                     case 32:
                      jia_ = gpio_get_level(jia);
                      if(jia_==0)
                      {
                          system_delay_ms(200);
                          xf_kp+=0.1;
                      }
                      jian_ = gpio_get_level(jian);
                      if(jian_==0)
                      {
                          system_delay_ms(200);
                          xf_kp-=0.1;
                      }
                      break;
                     case 48:
                      jia_ = gpio_get_level(jia);
                      if(jia_==0)
                      {
                          system_delay_ms(200);
                          xf_kd+=1;
                      }
                      jian_ = gpio_get_level(jian);
                      if(jian_==0)
                      {
                          system_delay_ms(200);
                          xf_kd-=1;
                      }
                      break;
                     case 64:
                      jia_ = gpio_get_level(jia);
                      if(jia_==0)
                      {
                          system_delay_ms(200);
                          Speed_I+=0.01;
                      }
                      jian_ = gpio_get_level(jian);
                      if(jian_==0)
                      {
                          system_delay_ms(200);
                          Speed_I-=0.01;
                      }
                      break;
                     case 80:
                      jia_ = gpio_get_level(jia);
                      if(jia_==0)
                      {
                          system_delay_ms(200);
                          Speed_P+=0.01;
                      }
                      jian_ = gpio_get_level(jian);
                      if(jian_==0)
                      {
                          system_delay_ms(200);
                          Speed_P-=0.01;
                      }
                      break;
                     case 96:
                      jia_ = gpio_get_level(jia);
                      if(jia_==0)
                      {
                          system_delay_ms(200);
                          slow_r+=1;
                      }
                      jian_ = gpio_get_level(jian);
                      if(jian_==0)
                      {
                          system_delay_ms(200);
                          slow_r-=1;
                      }
                      break;
                 }
                tft180_show_string(16, 0, "p");
                tft180_show_int(48, 0, kp, 5);
                tft180_show_string(16, 16, "gp");
                tft180_show_float(48, 16, gz_p, 1,4);
                tft180_show_string(16, 32, "xp");
                tft180_show_float(48, 32, xf_kp, 2,3);
                tft180_show_string(16, 48, "xd");
                tft180_show_float(48, 48, xf_kd, 2,3);
                tft180_show_string(16, 64, "SI");
                tft180_show_float(48, 64, Speed_I,1,5);
                tft180_show_string(16, 80, "SP");
                tft180_show_float(48, 80, Speed_P,2,4);
                tft180_show_string(16, 96, "sl");
                tft180_show_int(48, 96, slow_r,5);
                break;
           }
           case 64:
           {
               tft180_show_string(16, 0, "z");
               tft180_show_float(16, 16, jifenjiaodu, 5,5);
           }
        }



































}
